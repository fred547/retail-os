package com.emtel.blink.till.model;

/**
 * Response model for Get Dynamic QR Transaction Status API.
 */
public class DynamicQRStatusResponse {
    private String transactionDescription;
    private String transactionResponse;
    private boolean transactionStatus;
    private String transactionStatusCode;

    public DynamicQRStatusResponse() {}

    public DynamicQRStatusResponse(String transactionDescription, String transactionResponse,
                                  boolean transactionStatus, String transactionStatusCode) {
        this.transactionDescription = transactionDescription;
        this.transactionResponse = transactionResponse;
        this.transactionStatus = transactionStatus;
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getTransactionDescription() {
        return transactionDescription;
    }

    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

    public String getTransactionResponse() {
        return transactionResponse;
    }

    public void setTransactionResponse(String transactionResponse) {
        this.transactionResponse = transactionResponse;
    }

    public boolean isTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(boolean transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }
}
