package com.emtel.blink.till.model;

/**
 * Response model for Transaction Status API.
 */
public class TransactionStatusResponse {
    private TransactionStatusData data;
    private Status status;

    public TransactionStatusResponse() {}

    public TransactionStatusResponse(TransactionStatusData data, Status status) {
        this.data = data;
        this.status = status;
    }

    public TransactionStatusData getData() {
        return data;
    }

    public void setData(TransactionStatusData data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
