package com.emtel.blink.till.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.properties.EncryptableProperties;

/**
 * Configuration class for Blink API endpoints and encryption keys.
 * Values are loaded from a properties file with Jasypt-encrypted sensitive data.
 * Falls back to defaults if properties file is not found or values are missing.
 */
public class BlinkConfig implements BlinkConfigInterface {

    private static final Logger logger = Logger.getLogger(BlinkConfig.class.getName());

    // Default properties file path (can be overridden)
    private static final String DEFAULT_PROPERTIES_FILE = "blink-config.properties";

    // Property keys
    private static final String UAT_TOKEN_URL_KEY = "blink.uat.tokenUrl";
    private static final String PROD_TOKEN_URL_KEY = "blink.prod.tokenUrl";
    private static final String UAT_TRANSACTION_STATUS_URL_KEY = "blink.uat.transactionStatusUrl";
    private static final String PROD_TRANSACTION_STATUS_URL_KEY = "blink.prod.transactionStatusUrl";
    private static final String UAT_QR_CODE_URL_KEY = "blink.uat.qrCodeUrl";
    private static final String PROD_QR_CODE_URL_KEY = "blink.prod.qrCodeUrl";
    private static final String UAT_AES_KEY_KEY = "blink.uat.aesKey";
    private static final String PROD_AES_KEY_KEY = "blink.prod.aesKey";
    private static final String UAT_AES_IV_KEY = "blink.uat.aesIv";
    private static final String PROD_AES_IV_KEY = "blink.prod.aesIv";
    private static final String UAT_USERNAME_KEY = "blink.uat.username";
    private static final String PROD_USERNAME_KEY = "blink.prod.username";
    private static final String UAT_PASSWORD_KEY = "blink.uat.password";
    private static final String PROD_PASSWORD_KEY = "blink.prod.password";

    // Fallback default values (for backward compatibility)
    private static final String UAT_BASE_URL_DEFAULT = "https://fin-pos.emtel.com";
    private static final String PROD_BASE_URL_DEFAULT = "https://fin-pos.emtel.com";
    private static final String UAT_TOKEN_URL_DEFAULT = UAT_BASE_URL_DEFAULT + "/oauth2/v1.0.0/token";
    private static final String PROD_TOKEN_URL_DEFAULT = PROD_BASE_URL_DEFAULT + "/oauth2/v1.0.0/token";
    private static final String UAT_TRANSACTION_STATUS_URL_DEFAULT = UAT_BASE_URL_DEFAULT + "/dynamicqr/v1.0.0/GetTransactionStatus";
    private static final String PROD_TRANSACTION_STATUS_URL_DEFAULT = PROD_BASE_URL_DEFAULT + "/dynamicqr/v1.0.0/GetTransactionStatus";
    private static final String UAT_QR_CODE_URL_DEFAULT = UAT_BASE_URL_DEFAULT + "/dynamicqr/v1.0.0/GetDynamicQR";
    private static final String PROD_QR_CODE_URL_DEFAULT = PROD_BASE_URL_DEFAULT + "/dynamicqr/v1.0.0/GetDynamicQR";
    private static final String UAT_AES_KEY_DEFAULT = "p9Tf3Xo1LcGq7Yzv6NRmKb4W2uJX8OaQ";
    private static final String PROD_AES_KEY_DEFAULT = "p9Tf3Xo1LcGq7Yzv6NRmKb4W2uJX8OaQ";
    private static final String UAT_AES_IV_DEFAULT = "tQxL2uB9eFkW1p4v";
    private static final String PROD_AES_IV_DEFAULT = "tQxL2uB9eFkW1p4v";
    private static final String UAT_USERNAME_DEFAULT = "kDucffkf9MGvtOwLFqGIpsKIQVoa";
    private static final String PROD_USERNAME_DEFAULT = "kDucffkf9MGvtOwLFqGIpsKIQVoa";
    private static final String UAT_PASSWORD_DEFAULT = "nGfzdLlnVGfM1oyfToWAY3I4lxQa";
    private static final String PROD_PASSWORD_DEFAULT = "nGfzdLlnVGfM1oyfToWAY3I4lxQa";

    // Jasypt encryption password (should be set via environment variable or secure keystore)
    private static final String JASYPT_PASSWORD = System.getenv("JASYPT_ENCRYPTOR_PASSWORD") != null ?
        System.getenv("JASYPT_ENCRYPTOR_PASSWORD") : "defaultJasyptPassword"; // TODO: Secure this!

    private Properties properties;
    private boolean isProduction;
    private StandardPBEStringEncryptor encryptor;

    /**
     * Constructor with default properties file.
     */
    public BlinkConfig(boolean isProduction) {
        this(isProduction, DEFAULT_PROPERTIES_FILE);
    }

    /**
     * Constructor with custom properties file path.
     * @param isProduction true for production, false for UAT
     * @param propertiesFilePath path to properties file (file system or classpath)
     */
    public BlinkConfig(boolean isProduction, String propertiesFilePath) {
        this.isProduction = isProduction;
        this.encryptor = createEncryptor();
        this.properties = loadProperties(propertiesFilePath);
        validateHttpsUrls();
    }

    /**
     * Creates and configures the Jasypt encryptor.
     */
    private StandardPBEStringEncryptor createEncryptor() {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(JASYPT_PASSWORD);
        encryptor.setAlgorithm("PBEWithMD5AndDES"); // Can be changed to stronger algorithm if needed
        return encryptor;
    }

    /**
     * Loads properties from file path or classpath using EncryptableProperties.
     */
    private Properties loadProperties(String propertiesFilePath) {
        Properties props = new EncryptableProperties(encryptor);
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(propertiesFilePath)) {
            if (input != null) {
                props.load(input);
                logger.info("Loaded encrypted properties from classpath: " + propertiesFilePath);
            } else {
                // Try file system path
                try (FileInputStream fis = new FileInputStream(propertiesFilePath)) {
                    props.load(fis);
                    logger.info("Loaded encrypted properties from file system: " + propertiesFilePath);
                } catch (IOException e) {
                    logger.log(Level.WARNING, "Properties file not found at " + propertiesFilePath + ", using defaults", e);
                }
            }
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error loading properties file, using defaults", e);
        }
        return props;
    }

    /**
     * Validates that all URLs use HTTPS for security.
     */
    private void validateHttpsUrls() {
        String[] urls = {getTokenUrl(), getTransactionStatusUrl(), getQrCodeUrl()};
        for (String url : urls) {
            if (!url.startsWith("https://")) {
                throw new IllegalStateException("Security violation: URL must use HTTPS: " + url);
            }
        }
    }

    /**
     * Gets a property value, with automatic decryption if encrypted.
     */
    private String getProperty(String key, String defaultValue) {
        String value = properties.getProperty(key);
        if (value == null || value.trim().isEmpty()) {
            logger.log(Level.WARNING, "Property " + key + " not found, using default value");
            return defaultValue;
        }
        return value; // Jasypt handles decryption automatically via EncryptableProperties
    }

    public String getTokenUrl() {
        return getProperty(isProduction ? PROD_TOKEN_URL_KEY : UAT_TOKEN_URL_KEY,
                          isProduction ? PROD_TOKEN_URL_DEFAULT : UAT_TOKEN_URL_DEFAULT);
    }

    public String getTransactionStatusUrl() {
        return getProperty(isProduction ? PROD_TRANSACTION_STATUS_URL_KEY : UAT_TRANSACTION_STATUS_URL_KEY,
                          isProduction ? PROD_TRANSACTION_STATUS_URL_DEFAULT : UAT_TRANSACTION_STATUS_URL_DEFAULT);
    }

    public String getQrCodeUrl() {
        return getProperty(isProduction ? PROD_QR_CODE_URL_KEY : UAT_QR_CODE_URL_KEY,
                          isProduction ? PROD_QR_CODE_URL_DEFAULT : UAT_QR_CODE_URL_DEFAULT);
    }

    public String getAesKey() {
        return getProperty(isProduction ? PROD_AES_KEY_KEY : UAT_AES_KEY_KEY,
                          isProduction ? PROD_AES_KEY_DEFAULT : UAT_AES_KEY_DEFAULT);
    }

    public String getAesIv() {
        return getProperty(isProduction ? PROD_AES_IV_KEY : UAT_AES_IV_KEY,
                          isProduction ? PROD_AES_IV_DEFAULT : UAT_AES_IV_DEFAULT);
    }

    public String getUsername() {
        return getProperty(isProduction ? PROD_USERNAME_KEY : UAT_USERNAME_KEY,
                          isProduction ? PROD_USERNAME_DEFAULT : UAT_USERNAME_DEFAULT);
    }

    public String getPassword() {
        return getProperty(isProduction ? PROD_PASSWORD_KEY : UAT_PASSWORD_KEY,
                          isProduction ? PROD_PASSWORD_DEFAULT : UAT_PASSWORD_DEFAULT);
    }

    public boolean isProduction() {
        return isProduction;
    }

    public void setProduction(boolean production) {
        isProduction = production;
    }
}
