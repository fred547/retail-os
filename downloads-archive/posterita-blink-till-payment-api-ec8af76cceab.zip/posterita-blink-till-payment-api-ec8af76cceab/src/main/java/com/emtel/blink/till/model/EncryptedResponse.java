package com.emtel.blink.till.model;

/**
 * Response model for encrypted API responses.
 */
public class EncryptedResponse {
    private String data;
    private Status status;

    public EncryptedResponse() {}

    public EncryptedResponse(String data, Status status) {
        this.data = data;
        this.status = status;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
