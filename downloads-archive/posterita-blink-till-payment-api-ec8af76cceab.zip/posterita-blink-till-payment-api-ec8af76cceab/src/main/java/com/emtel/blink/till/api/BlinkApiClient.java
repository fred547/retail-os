package com.emtel.blink.till.api;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.emtel.blink.till.config.BlinkConfig;
import com.emtel.blink.till.crypto.AESEncryptionUtil;
import com.emtel.blink.till.model.EncryptedResponse;
import com.emtel.blink.till.model.QRCodeRequest;
import com.emtel.blink.till.model.QRCodeResponse;
import com.emtel.blink.till.model.TokenResponse;
import com.emtel.blink.till.model.TransactionStatusRequest;
import com.emtel.blink.till.model.TransactionStatusResponse;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Main API client for Blink Payment System.
 * Handles authentication, encryption, and all API calls.
 */
public class BlinkApiClient implements BlinkApiClientInterface {

    private static final Logger logger = Logger.getLogger(BlinkApiClient.class.getName());
    private static final String JSON_CONTENT_TYPE = "application/json; charset=utf-8";

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final BlinkConfig config;

    private String currentToken;
    private long tokenExpiryTime;

    public BlinkApiClient(BlinkConfig config) {
        this.config = config;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * Creates a common HttpRequest.Builder with shared headers.
     */
    private HttpRequest.Builder createRequestBuilder(URI uri) {
        return HttpRequest.newBuilder()
                .uri(uri)
                .header("Content-Type", JSON_CONTENT_TYPE)
                .header("User-Agent", "okhttp/4.12.0");
    }

    /**
     * Validates input parameters for security.
     *
     * @param value the value to validate
     * @param fieldName the field name for error messages
     * @throws IllegalArgumentException if validation fails
     */
    private void validateInput(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be null or empty");
        }
        if (value.length() > 100) { // Reasonable limit
            throw new IllegalArgumentException(fieldName + " is too long");
        }
        // Check for potentially dangerous characters
        if (value.contains("<") || value.contains(">") || value.contains("\"") || value.contains("'")) {
            throw new IllegalArgumentException(fieldName + " contains invalid characters");
        }
    }

    /**
     * Validates transaction amount.
     *
     * @param amount the amount to validate
     * @throws IllegalArgumentException if validation fails
     */
    private void validateAmount(BigDecimal amount) {
        if (amount == null) {
            throw new IllegalArgumentException("Transaction amount cannot be null");
        }
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Transaction amount must be positive");
        }
        if (amount.scale() > 2) {
            throw new IllegalArgumentException("Transaction amount cannot have more than 2 decimal places");
        }
        if (amount.compareTo(new BigDecimal("1000000")) > 0) { // Reasonable upper limit
            throw new IllegalArgumentException("Transaction amount is too large");
        }
    }

    /**
     * Authenticates and retrieves a token.
     *
     * @return String
     * @throws IOException if request fails
     */
    public TokenResponse authenticate() throws IOException, BlinkApiException {
        
    	// Encode username:password in Base64
        String auth = config.getUsername() + ":" + config.getPassword();
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes());
        
        String formData = "grant_type=" + URLEncoder.encode("client_credentials", StandardCharsets.UTF_8);

        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(config.getTokenUrl()))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .header("User-Agent", "okhttp/4.12.0")
                .header("Accept", "application/json, text/plain")
                .header("Accept-Encoding", "deflate")
                .header("Authorization", "Basic " + encodedAuth)
                .POST(HttpRequest.BodyPublishers.ofString(formData))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.INFO, "Auth response status: " + response.statusCode()); 
            
            JsonNode node = objectMapper.readTree(responseBody);
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String errorMsg = "Authentication failed: " + response.statusCode() + " " + node.path("error_description").asText("");
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }    
            
            TokenResponse tokenResponse = objectMapper.readValue(responseBody, TokenResponse.class);
            
           // Update current token and session
            this.currentToken = tokenResponse.getAccess_token();
            this.tokenExpiryTime = System.currentTimeMillis() + (tokenResponse.getExpires_in() * 60 * 1000);
            logger.log(Level.INFO, "Authentication successful, token expires in " + tokenResponse.getExpires_in() + " minutes");

            
            return tokenResponse;
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.log(Level.SEVERE, "Request interrupted", e);
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Checks if the current token is valid.
     *
     * @return true if token is valid
     */
    public boolean isTokenValid() {
        return currentToken != null && System.currentTimeMillis() < tokenExpiryTime;
    }

    /**
     * Ensures the token is valid by refreshing if necessary.
     *
     * @throws IOException if refresh fails
     * @throws BlinkApiException if API error during refresh
     */
    private void ensureTokenValid() throws IOException, BlinkApiException {
        if (!isTokenValid()) {
            logger.log(Level.INFO, "Token expired, refreshing...");
            authenticate();
        }
    }

    
    /**
     * Gets transaction status.
     *
     * @param statusRequest the status request
     * @return TransactionStatusResponse
     * @throws IOException if request fails
     */
    public TransactionStatusResponse getTransactionStatus(TransactionStatusRequest statusRequest) throws IOException, BlinkApiException {
        // Input validation
        if (statusRequest == null) {
            throw new IllegalArgumentException("Transaction status request cannot be null");
        }
        validateInput(statusRequest.getTerminalId(), "Terminal ID");
        validateInput(statusRequest.getTransactionId(), "Transaction ID");

        ensureTokenValid();

        String jsonRequest = objectMapper.writeValueAsString(statusRequest);

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getTransactionStatusUrl()))
        		.header("Authorization", "Bearer " + this.currentToken)
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            String responseBody = response.body();
            // Log response status but not the full body for security
            logger.log(Level.INFO, "Transaction status response status: " + response.statusCode());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String errorMsg = "Transaction status request failed: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }

            return objectMapper.readValue(responseBody, TransactionStatusResponse.class);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.log(Level.SEVERE, "Request interrupted", e);
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Gets QR Code.
     *
     * @param qrRequest the QR code request
     * @return QRCodeResponse
     * @throws Exception if request fails
     */
    public QRCodeResponse getQRCode(QRCodeRequest qrRequest) throws Exception {
        // Input validation for security
        if (qrRequest == null) {
            throw new IllegalArgumentException("QR code request cannot be null");
        }
        validateInput(qrRequest.getMerchant_id(), "Merchant ID");
        validateInput(qrRequest.getStore_id(), "Store ID");
        validateInput(qrRequest.getTerminal_id(), "Terminal ID");
        validateInput(qrRequest.getTransaction_id(), "Transaction ID");
        if (qrRequest.getAmount() != null) {
            validateAmount(qrRequest.getAmount().getValue());
        } else {
            throw new IllegalArgumentException("QR code request amount cannot be null");
        }

        try {
            ensureTokenValid();
        } catch (IOException | BlinkApiException e) {
            logger.log(Level.SEVERE, "Failed to ensure token valid", e);
            throw new IllegalStateException("Token is invalid and refresh failed", e);
        }
        
        String jsonRequest = objectMapper.writeValueAsString(qrRequest);
        
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getQrCodeUrl()))
        		.header("Authorization", "Bearer " + this.currentToken)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            String responseBody = response.body();
            // Log response status but not the full body for security
            logger.log(Level.INFO, "QR Code response status: " + response.statusCode());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String errorMsg = "QR Code request failed: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);
            
            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            logger.log(Level.FINE, "QR Code decrypted response processed");
            
            decryptedData = objectMapper.readValue(decryptedData, String.class);
            
            return objectMapper.readValue(decryptedData, QRCodeResponse.class);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.log(Level.SEVERE, "Request interrupted", e);
            throw new IOException("Request interrupted", e);
        }
    }
    
    
}
