package com.emtel.blink.till;

import com.emtel.blink.till.api.BlinkApiClient;
import com.emtel.blink.till.api.BlinkApiClientInterface;
import com.emtel.blink.till.config.BlinkConfig;
import com.emtel.blink.till.model.*;

/**
 * Main facade class for Blink Payment API Library.
 * Provides high-level methods for all payment operations.
 */
public class BlinkPaymentApi {

    private final BlinkApiClientInterface client;

    /**
     * Creates a new instance for UAT environment.
     */
    public BlinkPaymentApi() {
        this(false);
    }

    /**
     * Creates a new instance for the specified environment.
     *
     * @param isProduction true for production, false for UAT
     */
    public BlinkPaymentApi(boolean isProduction) {
        BlinkConfig config = new BlinkConfig(isProduction);
        this.client = new BlinkApiClient(config);
    }
    
    /**
     * Creates a new instance for the specified config.
     *
     * @param config
     */
    public BlinkPaymentApi(BlinkConfig config) {
        this.client = new BlinkApiClient(config);
    }

    /**
     * Creates a new instance with the specified API client (for testing).
     *
     * @param client the API client to use
     */
    public BlinkPaymentApi(BlinkApiClientInterface client) {
        this.client = client;
    }

    /**
     * Authenticates with the Blink API and retrieves an access token.
     * This method must be called before making any other API calls.
     *
     * @return TokenResponse containing access token and expiration details
     * @throws Exception if authentication fails (network error, invalid credentials, etc.)
     */
    public TokenResponse authenticate() throws Exception {
        return client.authenticate();
    }
    
    /**
     * Gets QR Code for payment.
     *
     * @param qrRequest the QR code request containing merchant, store, terminal, transaction details and amount
     * @return QRCodeResponse containing the QR code data
     * @throws Exception if the request fails
     */
    public QRCodeResponse getQRCode(QRCodeRequest qrRequest) throws Exception {
        return client.getQRCode(qrRequest);
    }

    
    /**
     * Retrieves the status of a transaction.
     * Requires prior authentication.
     *
     * @param terminalId the terminal identifier
     * @param transactionId the transaction identifier to check
     * @return TransactionStatusResponse containing transaction status details
     * @throws Exception if request fails or authentication is invalid
     */
    public TransactionStatusResponse getTransactionStatus(String terminalId, String transactionId) throws Exception {
        TransactionStatusRequest request = new TransactionStatusRequest(terminalId, transactionId);
        return client.getTransactionStatus(request);
    }

    
    
    
}
