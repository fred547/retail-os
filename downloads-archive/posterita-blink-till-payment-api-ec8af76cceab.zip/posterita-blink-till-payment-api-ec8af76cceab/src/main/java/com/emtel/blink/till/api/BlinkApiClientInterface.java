package com.emtel.blink.till.api;

import java.math.BigDecimal;

import com.emtel.blink.till.model.QRCodeRequest;
import com.emtel.blink.till.model.QRCodeResponse;
import com.emtel.blink.till.model.TokenResponse;
import com.emtel.blink.till.model.TransactionStatusRequest;
import com.emtel.blink.till.model.TransactionStatusResponse;

/**
 * Interface for Blink API client operations.
 * Enables easier testing and mocking.
 */
public interface BlinkApiClientInterface {

    /**
     * Authenticates with the Blink API and retrieves an access token.
     *
     * @return TokenResponse containing access token and expiration details
     * @throws Exception if authentication fails
     */
    TokenResponse authenticate() throws Exception;

    /**
     * Checks if the current token is valid.
     *
     * @return true if token is valid and not expired
     */
    boolean isTokenValid();

    /**
     * Retrieves the status of a transaction.
     *
     * @param statusRequest the transaction status request
     * @return TransactionStatusResponse containing transaction details
     * @throws Exception if request fails
     */
    TransactionStatusResponse getTransactionStatus(TransactionStatusRequest statusRequest) throws Exception;

    /**
     * Generates a QR code for payment processing.
     *
     * @param qrRequest the QR code request containing all necessary parameters
     * @return QRCodeResponse containing QR code details
     * @throws Exception if request fails
     */
    QRCodeResponse getQRCode(QRCodeRequest qrRequest) throws Exception;
}
