package com.emtel.blink.till.config;

/**
 * Interface for Blink configuration.
 * Enables easier testing and mocking of configuration.
 */
public interface BlinkConfigInterface {

    /**
     * Gets the token endpoint URL.
     *
     * @return the token URL
     */
    String getTokenUrl();

    /**
     * Gets the transaction status endpoint URL.
     *
     * @return the transaction status URL
     */
    String getTransactionStatusUrl();

    /**
     * Gets the QR code endpoint URL.
     *
     * @return the QR code URL
     */
    String getQrCodeUrl();

    /**
     * Gets the AES encryption key.
     *
     * @return the AES key
     */
    String getAesKey();

    /**
     * Gets the AES initialization vector.
     *
     * @return the AES IV
     */
    String getAesIv();

    /**
     * Gets the username for authentication.
     *
     * @return the username
     */
    String getUsername();

    /**
     * Gets the password for authentication.
     *
     * @return the password
     */
    String getPassword();

    /**
     * Checks if this is production environment.
     *
     * @return true if production, false if UAT
     */
    boolean isProduction();

    /**
     * Sets the production flag.
     *
     * @param production true for production, false for UAT
     */
    void setProduction(boolean production);
}
