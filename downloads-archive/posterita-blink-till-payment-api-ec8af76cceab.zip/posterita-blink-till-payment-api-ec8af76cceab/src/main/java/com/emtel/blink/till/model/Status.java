package com.emtel.blink.till.model;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Represents the status response from API calls.
 */
public class Status {
    @JsonProperty("i")
    private boolean i; // isSuccess

    @JsonProperty("m")
    private String m;  // message

    @JsonProperty("s")
    private String s;  // statusCode

    public Status() {}

    public Status(boolean i, String m, String s) {
        this.i = i;
        this.m = m;
        this.s = s;
    }

    public boolean isSuccess() {
        return i;
    }

    public void setSuccess(boolean i) {
        this.i = i;
    }

    public String getMessage() {
        return m;
    }

    public void setMessage(String m) {
        this.m = m;
    }

    public String getStatusCode() {
        return s;
    }

    public void setStatusCode(String s) {
        this.s = s;
    }

    @Override
    public String toString() {
        return "Status{" +
                "isSuccess=" + i +
                ", message='" + m + '\'' +
                ", statusCode='" + s + '\'' +
                '}';
    }
}
