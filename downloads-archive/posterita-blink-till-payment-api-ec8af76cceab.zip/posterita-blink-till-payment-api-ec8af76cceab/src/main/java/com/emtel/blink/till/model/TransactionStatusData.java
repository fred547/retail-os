package com.emtel.blink.till.model;

/**
 * Data model for Transaction Status response.
 */
public class TransactionStatusData {
    private String transactionId;
    private String statusDescription;
    private String transactionResponse;
    private boolean transactionStatus;
    private String transactionStatusCode;

    public TransactionStatusData() {}

    public TransactionStatusData(String transactionId, String statusDescription, String transactionResponse,
                                boolean transactionStatus, String transactionStatusCode) {
        this.transactionId = transactionId;
        this.statusDescription = statusDescription;
        this.transactionResponse = transactionResponse;
        this.transactionStatus = transactionStatus;
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getTransactionResponse() {
        return transactionResponse;
    }

    public void setTransactionResponse(String transactionResponse) {
        this.transactionResponse = transactionResponse;
    }

    public boolean isTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(boolean transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }
}
