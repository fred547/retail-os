package com.emtel.blink.till.model;

import java.math.BigDecimal;

/**
 * Request model for Get QR Code API.
 */
public class QRCodeRequest {
    private String merchant_id;
    private String terminal_id;
    private String transaction_id;
    private String store_id;
    private Amount amount;

    public static class Amount {
        private String currency = "MUR";
        private BigDecimal value;

        public Amount(){}

        public Amount(BigDecimal value){
            this.value = value;
        }

        public Amount(String currency, BigDecimal value){
            this.currency = currency;
            this.value = value;
        }

        // Getters and setters
        public String getCurrency() { return currency; }
        public void setCurrency(String currency) { this.currency = currency; }
        public BigDecimal getValue() { return value; }
        public void setValue(BigDecimal value) { this.value = value; }
    }

    // Getters and setters
    public String getMerchant_id() { return merchant_id; }
    public void setMerchant_id(String merchant_id) { this.merchant_id = merchant_id; }
    public String getTerminal_id() { return terminal_id; }
    public void setTerminal_id(String terminal_id) { this.terminal_id = terminal_id; }
    public String getTransaction_id() { return transaction_id; }
    public void setTransaction_id(String transaction_id) { this.transaction_id = transaction_id; }
    public String getStore_id() { return store_id; }
    public void setStore_id(String store_id) { this.store_id = store_id; }
    public Amount getAmount() { return amount; }
    public void setAmount(Amount amount) { this.amount = amount; }
}
