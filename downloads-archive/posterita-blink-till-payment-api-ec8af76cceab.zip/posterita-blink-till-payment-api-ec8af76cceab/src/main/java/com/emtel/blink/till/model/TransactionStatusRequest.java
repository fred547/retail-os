package com.emtel.blink.till.model;

/**
 * Request model for Transaction Status API.
 */
public class TransactionStatusRequest {
	
    private String terminalId;
    private String transactionId;
    
    public TransactionStatusRequest() {}
    
	public TransactionStatusRequest(String terminalId, String transactionId) {
		super();
		this.terminalId = terminalId;
		this.transactionId = transactionId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}    
    
}
