package com.emtel.blink.till.crypto;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

/**
 * Utility class for encrypting/decrypting values using Jasypt.
 * Use this to encrypt sensitive values before placing them in the properties file.
 */
public class JasyptEncryptionUtil {

    // Use environment variable for password in production
    private static final String PASSWORD = System.getenv("JASYPT_ENCRYPTOR_PASSWORD") != null ?
        System.getenv("JASYPT_ENCRYPTOR_PASSWORD") : "defaultJasyptPassword";

    /**
     * Encrypts a plain text value using Jasypt.
     * @param plainText the value to encrypt
     * @return the encrypted value
     */
    public static String encrypt(String plainText) {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(PASSWORD);
        encryptor.setAlgorithm("PBEWithMD5AndDES");
        return encryptor.encrypt(plainText);
    }

    /**
     * Decrypts an encrypted value using Jasypt.
     * @param encryptedText the encrypted value to decrypt
     * @return the decrypted plain text
     */
    public static String decrypt(String encryptedText) {
        StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
        encryptor.setPassword(PASSWORD);
        encryptor.setAlgorithm("PBEWithMD5AndDES");
        return encryptor.decrypt(encryptedText);
    }

    /**
     * Example usage - run this main method to generate encrypted values for your properties file.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: java JasyptEncryptionUtil <value_to_encrypt>");
            System.out.println("Example: java JasyptEncryptionUtil mySecretPassword");
            return;
        }

        String originalValue = args[0];
        String encrypted = encrypt(originalValue);
        System.out.println("Original: " + originalValue);
        System.out.println("Encrypted: ENC(" + encrypted + ")");

        // Verify decryption works
        String decrypted = decrypt(encrypted);
        System.out.println("Decrypted: " + decrypted);
        System.out.println("Verification: " + originalValue.equals(decrypted));
    }
}
