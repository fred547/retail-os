package com.emtel.blink.till.api;

/**
 * Custom exception for Blink API errors.
 */
public class BlinkApiException extends Exception {
    private int statusCode;
    private String responseBody;

    public BlinkApiException(String message, int statusCode, String responseBody) {
        super(message);
        this.statusCode = statusCode;
        this.responseBody = responseBody;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getResponseBody() {
        return responseBody;
    }
}
