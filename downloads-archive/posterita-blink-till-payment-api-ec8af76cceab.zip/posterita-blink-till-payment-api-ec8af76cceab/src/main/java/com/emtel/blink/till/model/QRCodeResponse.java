package com.emtel.blink.till.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Response model for Get QR Code API.
 */
public class QRCodeResponse {
	
	private String transaction_id;
	private Timestamp timestamp;
	private String status;
	private String message;
	private Amount amount;	
	
	public QRCodeResponse() {}
	

	public QRCodeResponse(String transaction_id, Timestamp timestamp, String status, String message, Amount amount) {
		super();
		this.transaction_id = transaction_id;
		this.timestamp = timestamp;
		this.status = status;
		this.message = message;
		this.amount = amount;
	}



	public String getTransaction_id() {
		return transaction_id;
	}



	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}



	public Timestamp getTimestamp() {
		return timestamp;
	}



	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public String getMessage() {
		return message;
	}



	public void setMessage(String message) {
		this.message = message;
	}



	public Amount getAmount() {
		return amount;
	}



	public void setAmount(Amount amount) {
		this.amount = amount;
	}
	
	public static class Amount {
		private String currency;
		private BigDecimal value;
		
		public Amount() {}
		
		public Amount(String currency, BigDecimal value) {
			this.currency = currency;
			this.value = value;
		}

		public String getCurrency() {
			return currency;
		}

		public void setCurrency(String currency) {
			this.currency = currency;
		}

		public BigDecimal getValue() {
			return value;
		}

		public void setValue(BigDecimal value) {
			this.value = value;
		}		
		
	}
	
}
