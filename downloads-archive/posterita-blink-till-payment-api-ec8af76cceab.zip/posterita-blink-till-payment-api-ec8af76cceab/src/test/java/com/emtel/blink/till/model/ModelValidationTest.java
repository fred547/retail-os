package com.emtel.blink.till.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for model classes validation.
 */
public class ModelValidationTest {

    @Test
    void testTokenResponse() {
        TokenResponse response = new TokenResponse("token123", "bearer", "Bearer", 3600L);
        assertEquals("token123", response.getAccess_token());
        assertEquals("Bearer", response.getToken_type());
        assertEquals(3600L, response.getExpires_in());
    }

    @Test
    void testQRCodeResponse() {
        QRCodeResponse response = new QRCodeResponse();
        response.setTransaction_id("txn123");
        response.setStatus("SUCCESS");
        response.setMessage("QR generated");

        assertEquals("txn123", response.getTransaction_id());
        assertEquals("SUCCESS", response.getStatus());
        assertEquals("QR generated", response.getMessage());
    }

    @Test
    void testTransactionStatusRequest() {
        TransactionStatusRequest request = new TransactionStatusRequest("terminal1", "txn123");
        assertEquals("terminal1", request.getTerminalId());
        assertEquals("txn123", request.getTransactionId());
    }

    @Test
    void testStatus() {
        Status status = new Status(true, "OK", "200");
        assertTrue(status.isSuccess());
        assertEquals("OK", status.getMessage());
        assertEquals("200", status.getStatusCode());
    }

    @Test
    void testEncryptedResponse() {
        EncryptedResponse response = new EncryptedResponse("encrypted_data", new Status(true, "OK", "200"));
        assertEquals("encrypted_data", response.getData());
        assertTrue(response.getStatus().isSuccess());
    }
}
