package com.emtel.blink.till;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.logging.Logger;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;

import com.emtel.blink.till.model.QRCodeRequest;
import com.emtel.blink.till.model.QRCodeResponse;
import com.emtel.blink.till.model.TokenResponse;
import com.emtel.blink.till.model.TransactionStatusResponse;

/**
 * Integration tests for BlinkPaymentApi that make real API calls.
 * These tests require network connectivity and valid API credentials.
 * Use UAT environment for testing.
 *
 * To run these tests, set environment variable RUN_INTEGRATION_TESTS=true
 * and ensure proper credentials are set via environment variables.
 *
 * Required environment variables:
 * - BLINK_MERCHANT_ID
 * - BLINK_STORE_ID
 * - BLINK_TERMINAL_ID
 */
@EnabledIfEnvironmentVariable(named = "RUN_INTEGRATION_TESTS", matches = "true")
public class BinkIntegrationTest {

    private static final Logger logger = Logger.getLogger(BinkIntegrationTest.class.getName());
    private final BlinkPaymentApi api = new BlinkPaymentApi(false); // UAT environment

    @Test
    public void testRealAuthentication() throws Exception {
        TokenResponse response = api.authenticate();

        assertNotNull(response, "Authentication response should not be null");
        assertNotNull(response.getAccess_token(), "Access token should not be null");
        assertNotNull(response.getToken_type(), "Token type should not be null");
        assertTrue(response.getExpires_in() > 0, "Token expiration should be greater than 0");

        logger.info("✅ Authentication successful:");
        logger.info("Token: " + response.getAccess_token().substring(0, 20) + "...");
        logger.info("Token Type: " + response.getToken_type());
        logger.info("Expires in: " + response.getExpires_in() + " seconds");
    }

    @Test
    public void testRealQRCodeGeneration() throws Exception {
        // First authenticate
        TokenResponse authResponse = api.authenticate();
        assertNotNull(authResponse.getAccess_token(), "Authentication should succeed before QR generation");

        // Get test data from environment variables or use defaults
        String merchantId = System.getenv().getOrDefault("BLINK_MERCHANT_ID", "10586");
        String storeId = System.getenv().getOrDefault("BLINK_STORE_ID", "495");
        String terminalId = System.getenv().getOrDefault("BLINK_TERMINAL_ID", "392");
        String transactionId = "TEST" + System.currentTimeMillis();
        BigDecimal transactionAmount = new BigDecimal("0.01");

        // Create QR code request using the Amount constructor
        QRCodeRequest.Amount amount = new QRCodeRequest.Amount("MUR", transactionAmount);
        QRCodeRequest qrCodeRequest = new QRCodeRequest();
        qrCodeRequest.setMerchant_id(merchantId);
        qrCodeRequest.setStore_id(storeId);
        qrCodeRequest.setTerminal_id(terminalId);
        qrCodeRequest.setTransaction_id(transactionId);
        qrCodeRequest.setAmount(amount);

        // Generate QR code
        QRCodeResponse response = api.getQRCode(qrCodeRequest);

        assertNotNull(response, "QR code response should not be null");
        assertNotNull(response.getTransaction_id(), "Transaction ID should not be null");
        assertEquals(transactionId, response.getTransaction_id(), "Transaction ID should match request");

        logger.info("✅ QR Code generated successfully:");
        logger.info("Transaction ID: " + response.getTransaction_id());
        logger.info("Status: " + response.getStatus());
        logger.info("Message: " + response.getMessage());
    }

    @Test
    public void testRealTransactionStatus() throws Exception {
        // First authenticate
        TokenResponse authResponse = api.authenticate();
        assertNotNull(authResponse.getAccess_token(), "Authentication should succeed before status check");

        // Get test data from environment variables or use defaults
        String terminalId = System.getenv().getOrDefault("BLINK_TERMINAL_ID", "392");
        String transactionId = "TEST" + System.currentTimeMillis();

        try {
            TransactionStatusResponse response = api.getTransactionStatus(terminalId, transactionId);

            assertNotNull(response, "Transaction status response should not be null");
            assertNotNull(response.getData(), "Response data should not be null");
            assertNotNull(response.getStatus(), "Response status should not be null");

            logger.info("✅ Transaction Status retrieved:");
            logger.info("Transaction ID: " + response.getData().getTransactionId());
            logger.info("Status: " + response.getData().getTransactionResponse());
            logger.info("Status Code: " + response.getData().getTransactionStatusCode());

        } catch (Exception e) {
            // Transaction might not exist, which is expected for integration testing
            logger.warning("ℹ️  Transaction status test completed (expected for new transactions): " + e.getMessage());
            // This is not a test failure - new transactions won't have status
        }
    }
}
