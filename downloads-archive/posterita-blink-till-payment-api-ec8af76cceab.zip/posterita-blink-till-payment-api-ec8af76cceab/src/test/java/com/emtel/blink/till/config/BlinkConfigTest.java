package com.emtel.blink.till.config;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for BlinkConfig.
 */
public class BlinkConfigTest {

    @Test
    void testUatConfig() {
        BlinkConfig config = new BlinkConfig(false); // UAT
        assertFalse(config.isProduction());
        assertTrue(config.getTokenUrl().contains("fin-pos.emtel.com"));
        assertNotNull(config.getAesKey());
        assertNotNull(config.getUsername());
    }

    @Test
    void testProdConfig() {
        BlinkConfig config = new BlinkConfig(true); // PROD
        assertTrue(config.isProduction());
        assertTrue(config.getTokenUrl().contains("fin-pos.emtel.com"));
        assertNotNull(config.getAesKey());
        assertNotNull(config.getUsername());
    }

    @Test
    void testUrlGetters() {
        BlinkConfig config = new BlinkConfig(false);
        assertTrue(config.getTokenUrl().endsWith("/oauth2/v1.0.0/token"));
        assertTrue(config.getTransactionStatusUrl().endsWith("/dynamicqr/v1.0.0/GetTransactionStatus"));
        assertTrue(config.getQrCodeUrl().endsWith("/dynamicqr/v1.0.0/GetDynamicQR"));
    }
}
