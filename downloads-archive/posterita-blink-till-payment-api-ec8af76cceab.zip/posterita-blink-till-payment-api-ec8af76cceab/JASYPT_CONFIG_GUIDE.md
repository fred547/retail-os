# Blink Till Payment API - Jasypt Configuration Guide

## Overview
The BlinkConfig class now uses Jasypt for secure property encryption. This provides industry-standard encryption for sensitive configuration values while maintaining ease of use.

## Configuration Files
- **Location**: `src/main/resources/blink-config.properties`
- **Format**: Standard Java properties file with optional Jasypt encryption

## Property Structure
```properties
# Non-sensitive values (plain text)
blink.uat.tokenUrl=https://fin-pos.emtel.com/oauth2/v1.0.0/token

# Sensitive values (encrypted with Jasypt)
blink.uat.username=ENC(encrypted_username_here)
blink.uat.password=ENC(encrypted_password_here)
```

## Environment Variables
Set the Jasypt encryption password securely:
```bash
export JASYPT_ENCRYPTOR_PASSWORD=your_secure_password_here
```

## Encrypting Sensitive Values
Use the provided `JasyptEncryptionUtil` to encrypt your sensitive data:

### Method 1: Command Line
```bash
mvn exec:java -Dexec.mainClass="com.emtel.blink.till.crypto.JasyptEncryptionUtil" -Dexec.args="your_sensitive_value"
```

### Method 2: Programmatic Usage
```java
import com.emtel.blink.till.crypto.JasyptEncryptionUtil;

String encrypted = JasyptEncryptionUtil.encrypt("your_sensitive_value");
System.out.println("Use this in properties: ENC(" + encrypted + ")");
```

## Example Output
```
Original: mySecretPassword
Encrypted: ENC(gvXaZUTGT/rOgUSwFb6p4UTAetEsqhWdi2IK3SGQk0w=)
Decrypted: mySecretPassword
Verification: true
```

## Security Best Practices
1. **Never commit encrypted values to version control** - use placeholders initially
2. **Use strong encryption passwords** - set via environment variables
3. **Rotate encryption passwords periodically**
4. **Store encryption passwords securely** (environment variables, secure keystores)
5. **Use different passwords for different environments**

## Configuration Loading Priority
1. Properties file in classpath (`blink-config.properties`)
2. Properties file in file system (if specified)
3. Default fallback values (for backward compatibility)

## Migration from Environment Variables
If you were using environment variables, you can now:
1. Encrypt your sensitive values using `JasyptEncryptionUtil`
2. Update the properties file with `ENC(encrypted_value)` format
3. Remove the old environment variables (optional)

## Troubleshooting
- **EncryptionOperationNotPossibleException**: Check that your JASYPT_ENCRYPTOR_PASSWORD matches the one used for encryption
- **Properties not loading**: Ensure the properties file is in the correct location
- **Default values used**: Check logs for "Property X not found, using default value" messages

## Complete Properties File Example
```properties
# Blink Configuration Properties
blink.isProduction=false

# UAT Environment
blink.uat.baseUrl=https://fin-pos.emtel.com
blink.uat.tokenUrl=https://fin-pos.emtel.com/oauth2/v1.0.0/token
blink.uat.transactionStatusUrl=https://fin-pos.emtel.com/dynamicqr/v1.0.0/GetTransactionStatus
blink.uat.qrCodeUrl=https://fin-pos.emtel.com/dynamicqr/v1.0.0/GetDynamicQR
blink.uat.aesKey=ENC(encrypted_aes_key)
blink.uat.aesIv=ENC(encrypted_aes_iv)
blink.uat.username=ENC(encrypted_username)
blink.uat.password=ENC(encrypted_password)

# PROD Environment
blink.prod.baseUrl=https://fin-pos.emtel.com
blink.prod.tokenUrl=https://fin-pos.emtel.com/oauth2/v1.0.0/token
blink.prod.transactionStatusUrl=https://fin-pos.emtel.com/dynamicqr/v1.0.0/GetTransactionStatus
blink.prod.qrCodeUrl=https://fin-pos.emtel.com/dynamicqr/v1.0.0/GetDynamicQR
blink.prod.aesKey=ENC(encrypted_aes_key)
blink.prod.aesIv=ENC(encrypted_aes_iv)
blink.prod.username=ENC(encrypted_username)
blink.prod.password=ENC(encrypted_password)

# Status Update URL
blink.statusUpdateUrl=https://partner-provided-url.com/status-update
```</content>
<parameter name="filePath">/home/praveen/git/blink-till-payment-api/JASYPT_CONFIG_GUIDE.md
