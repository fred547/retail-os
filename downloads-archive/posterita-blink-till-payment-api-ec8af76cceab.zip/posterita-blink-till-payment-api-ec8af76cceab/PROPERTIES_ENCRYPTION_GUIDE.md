# PropertiesEncryptionUtil - Automated Properties Encryption

## Overview
The `PropertiesEncryptionUtil` is a utility class that automatically encrypts sensitive properties in configuration files using Jasypt encryption. It intelligently identifies which properties contain sensitive data and encrypts only those values, leaving non-sensitive configuration intact.

## Features
- **Automatic Detection**: Intelligently identifies sensitive properties based on naming patterns
- **Selective Encryption**: Only encrypts truly sensitive values (passwords, keys, secrets)
- **Preserves URLs**: Leaves URL properties unencrypted for readability
- **Command-line Interface**: Easy-to-use CLI for batch processing
- **Programmatic API**: Full programmatic access for integration
- **Jasypt Compatible**: Uses standard Jasypt ENC() format

## Usage

### Command Line Usage
```bash
# Basic usage
mvn exec:java -Dexec.mainClass="com.emtel.blink.till.crypto.PropertiesEncryptionUtil" \
  -Dexec.args="input.properties output.properties"

# With custom password
mvn exec:java -Dexec.mainClass="com.emtel.blink.till.crypto.PropertiesEncryptionUtil" \
  -Dexec.args="input.properties output.properties myCustomPassword"
```

### Programmatic Usage
```java
import com.emtel.blink.till.crypto.PropertiesEncryptionUtil;

// Using default password from environment
PropertiesEncryptionUtil util = new PropertiesEncryptionUtil();
util.encryptPropertiesFile("input.properties", "output.properties");

// Using custom password
PropertiesEncryptionUtil util = new PropertiesEncryptionUtil("myCustomPassword");
util.encryptPropertiesFile("input.properties", "output.properties");

// Encrypt from classpath resource
util.encryptPropertiesResource("config/application.properties", "encrypted.properties");
```

## Encryption Rules

### Properties That Get Encrypted
The utility automatically encrypts properties whose keys contain these keywords (case-insensitive):
- `aeskey` - AES encryption keys
- `aesiv` - AES initialization vectors
- `username` - Usernames
- `password` - Passwords
- `secret` - Secret values
- `privatekey` - Private keys
- `apikey` - API keys

### Properties That Remain Unencrypted
Even if they contain sensitive keywords, these properties are left as plain text:
- `*tokenurl*` - Token URLs
- `*statusurl*` - Status URLs
- `*baseurl*` - Base URLs
- `*qrcodeurl*` - QR code URLs
- `*transactionstatusurl*` - Transaction status URLs

## Example

### Input Properties File (`application.properties`)
```properties
# Database configuration
database.url=jdbc:mysql://localhost:3306/mydb
database.username=admin
database.password=mySecretPassword123

# API configuration
api.baseUrl=https://api.example.com
api.tokenUrl=https://api.example.com/oauth/token
api.secretKey=myApiSecretKey456

# Application settings
app.name=MyApplication
app.version=1.0.0
logging.level=INFO
```

### Output Encrypted Properties File
```properties
# Database configuration
database.url=jdbc:mysql://localhost:3306/mydb
database.username=ENC(encrypted_username_here)
database.password=ENC(encrypted_password_here)

# API configuration
api.baseUrl=https://api.example.com
api.tokenUrl=https://api.example.com/oauth/token
api.secretKey=ENC(encrypted_secret_key_here)

# Application settings
app.name=MyApplication
app.version=1.0.0
logging.level=INFO
```

## Environment Variables
Set the encryption password securely:
```bash
export JASYPT_ENCRYPTOR_PASSWORD=your_secure_password_here
```

## Security Best Practices
1. **Never commit encrypted files to version control** with real sensitive data
2. **Use strong encryption passwords** (minimum 16 characters recommended)
3. **Store encryption passwords securely** (environment variables, secure keystores)
4. **Rotate encryption passwords periodically**
5. **Keep plain-text versions only during development**

## Integration with Existing Systems
The utility can be integrated into your build process or deployment pipeline:

### Maven Profile Example
```xml
<profile>
    <id>encrypt-properties</id>
    <build>
        <plugins>
            <plugin>
                <groupId>org.codehaus.mojo</groupId>
                <artifactId>exec-maven-plugin</artifactId>
                <version>3.5.1</version>
                <executions>
                    <execution>
                        <phase>prepare-package</phase>
                        <goals>
                            <goal>java</goal>
                        </goals>
                        <configuration>
                            <mainClass>com.emtel.blink.till.crypto.PropertiesEncryptionUtil</mainClass>
                            <arguments>
                                <argument>src/main/resources/application.properties</argument>
                                <argument>src/main/resources/application-encrypted.properties</argument>
                            </arguments>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</profile>
```

### Gradle Task Example
```gradle
task encryptProperties(type: JavaExec) {
    classpath = sourceSets.main.runtimeClasspath
    mainClass = 'com.emtel.blink.till.crypto.PropertiesEncryptionUtil'
    args 'src/main/resources/application.properties', 'src/main/resources/application-encrypted.properties'
}
```

## Troubleshooting
- **EncryptionOperationNotPossibleException**: Verify the JASYPT_ENCRYPTOR_PASSWORD matches
- **File not found**: Ensure input file path is correct and accessible
- **Already encrypted values**: The utility skips properties already in ENC() format
- **Wrong properties encrypted**: Modify the SENSITIVE_PROPERTIES and NON_SENSITIVE_EXCEPTIONS sets

## Advanced Configuration
You can customize the encryption behavior by modifying the static sets in the source code:

```java
// Add custom sensitive keywords
private static final Set<String> SENSITIVE_PROPERTIES = Set.of(
    "aeskey", "aesiv", "username", "password", "secret", "myCustomField"
);

// Add custom exceptions
private static final Set<String> NON_SENSITIVE_EXCEPTIONS = Set.of(
    "tokenurl", "statusurl", "mycustomurl"
);
```

This utility makes it easy to maintain encrypted configuration files while keeping your development workflow efficient and secure.</content>
<parameter name="filePath">/home/praveen/git/blink-till-payment-api/PROPERTIES_ENCRYPTION_GUIDE.md
