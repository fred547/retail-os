package com.emtel.blink.dynamicqrcode.model;

import java.math.BigDecimal;

/**
 * Request model for Debit/Initiate Transaction API.
 */
public class DebitRequest {
    private String merchantQRCode;
    private String merchantStoreMobileNo;
    private String customerMobileNo;
    private BigDecimal amount;
    private String requestUUID;
    private String requestIndentityId;

    public DebitRequest() {}

    public DebitRequest(String merchantQRCode, String merchantStoreMobileNo, String customerMobileNo,
                       BigDecimal amount, String requestUUID, String requestIndentityId) {
        this.merchantQRCode = merchantQRCode;
        this.merchantStoreMobileNo = merchantStoreMobileNo;
        this.customerMobileNo = customerMobileNo;
        this.amount = amount;
        this.requestUUID = requestUUID;
        this.requestIndentityId = requestIndentityId;
    }

    public String getMerchantQRCode() {
        return merchantQRCode;
    }

    public void setMerchantQRCode(String merchantQRCode) {
        this.merchantQRCode = merchantQRCode;
    }

    public String getMerchantStoreMobileNo() {
        return merchantStoreMobileNo;
    }

    public void setMerchantStoreMobileNo(String merchantStoreMobileNo) {
        this.merchantStoreMobileNo = merchantStoreMobileNo;
    }

    public String getCustomerMobileNo() {
        return customerMobileNo;
    }

    public void setCustomerMobileNo(String customerMobileNo) {
        this.customerMobileNo = customerMobileNo;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getRequestIndentityId() {
        return requestIndentityId;
    }

    public void setRequestIndentityId(String requestIndentityId) {
        this.requestIndentityId = requestIndentityId;
    }
}
