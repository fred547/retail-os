package com.emtel.blink.dynamicqrcode.model;

/**
 * Request model for Status Update API.
 */
public class StatusUpdateRequest {
    private String requestUUID;
    private String requestId; // PeachrequestId in doc, probably requestId
    private String transactionId;
    private String transactionStatusCode;
    private String transactionStatus;
    private String statusDescription;

    public StatusUpdateRequest() {}

    public StatusUpdateRequest(String requestUUID, String requestId, String transactionId,
                              String transactionStatusCode, String transactionStatus, String statusDescription) {
        this.requestUUID = requestUUID;
        this.requestId = requestId;
        this.transactionId = transactionId;
        this.transactionStatusCode = transactionStatusCode;
        this.transactionStatus = transactionStatus;
        this.statusDescription = statusDescription;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }
}
