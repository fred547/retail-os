package com.emtel.blink.dynamicqrcode.model;

import java.math.BigDecimal;

/**
 * Request model for Get QR Code API.
 */
public class QRCodeRequest {
    private String requestUUID;
    private String requestIndentityId;
    private String qrCodeString;
    private String purposeOfTransaction;
    private BigDecimal transactionAmount;
    private BigDecimal convenienceCharges;
    private boolean isPercentageConvenienceCharges;

    public QRCodeRequest() {}

    public QRCodeRequest(String requestUUID, String requestIndentityId, String qrCodeString,
                        String purposeOfTransaction, BigDecimal transactionAmount,
                        BigDecimal convenienceCharges, boolean isPercentageConvenienceCharges) {
        this.requestUUID = requestUUID;
        this.requestIndentityId = requestIndentityId;
        this.qrCodeString = qrCodeString;
        this.purposeOfTransaction = purposeOfTransaction;
        this.transactionAmount = transactionAmount;
        this.convenienceCharges = convenienceCharges;
        this.isPercentageConvenienceCharges = isPercentageConvenienceCharges;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getRequestIndentityId() {
        return requestIndentityId;
    }

    public void setRequestIndentityId(String requestIndentityId) {
        this.requestIndentityId = requestIndentityId;
    }

    public String getQrCodeString() {
        return qrCodeString;
    }

    public void setQrCodeString(String qrCodeString) {
        this.qrCodeString = qrCodeString;
    }

    public String getPurposeOfTransaction() {
        return purposeOfTransaction;
    }

    public void setPurposeOfTransaction(String purposeOfTransaction) {
        this.purposeOfTransaction = purposeOfTransaction;
    }

    public BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public BigDecimal getConvenienceCharges() {
        return convenienceCharges;
    }

    public void setConvenienceCharges(BigDecimal convenienceCharges) {
        this.convenienceCharges = convenienceCharges;
    }

    public boolean isPercentageConvenienceCharges() {
        return isPercentageConvenienceCharges;
    }

    public void setPercentageConvenienceCharges(boolean percentageConvenienceCharges) {
        isPercentageConvenienceCharges = percentageConvenienceCharges;
    }
}
