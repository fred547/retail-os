package com.emtel.blink.dynamicqrcode.model;

/**
 * Response model for Token API.
 */
public class TokenResponse {
    private TokenData data;
    private Status status;

    public TokenResponse() {}

    public TokenResponse(TokenData data, Status status) {
        this.data = data;
        this.status = status;
    }

    public TokenData getData() {
        return data;
    }

    public void setData(TokenData data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
