package com.emtel.blink.dynamicqrcode.model;

/**
 * Response model for Debit API.
 */
public class DebitResponse {
    private DebitData data;
    private Status status;

    public DebitResponse() {}

    public DebitResponse(DebitData data, Status status) {
        this.data = data;
        this.status = status;
    }

    public DebitData getData() {
        return data;
    }

    public void setData(DebitData data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
