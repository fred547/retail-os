package com.emtel.blink.dynamicqrcode;

import com.emtel.blink.dynamicqrcode.api.BlinkApiClient;
import com.emtel.blink.dynamicqrcode.config.BlinkConfig;
import com.emtel.blink.dynamicqrcode.model.*;

/**
 * Main facade class for Blink Payment API Library.
 * Provides high-level methods for all payment operations.
 */
public class BlinkPaymentApi {

    private final BlinkApiClient client;

    public BlinkPaymentApi() {
        BlinkConfig config = BlinkConfig.getConfig();
        this.client = new BlinkApiClient(config);
    }
    
    public BlinkPaymentApi(BlinkConfig config) {
        this.client = new BlinkApiClient(config);
    }

    /**
     * Creates a new instance with the specified API client (for testing).
     *
     * @param client the API client to use
     */
    public BlinkPaymentApi(BlinkApiClient client) {
        this.client = client;
    }

    /**
     * Authenticates with the Blink API.
     *
     * @param requestIndentityId unique request identity ID
     * @return TokenResponse
     * @throws Exception if authentication fails
     */
    public TokenResponse authenticate(String requestIndentityId) throws Exception {
        return client.authenticate(requestIndentityId);
    }

    /**
     * Initiates a debit transaction.
     *
     * @param merchantQRCode merchant QR code
     * @param merchantStoreMobileNo merchant store mobile number
     * @param customerMobileNo customer mobile number
     * @param amount transaction amount
     * @param requestUUID unique request UUID
     * @param requestIndentityId request identity ID
     * @return DebitResponse
     * @throws Exception if transaction fails
     */
    public DebitResponse initiateTransaction(String merchantQRCode, String merchantStoreMobileNo,
                                           String customerMobileNo, java.math.BigDecimal amount,
                                           String requestUUID, String requestIndentityId) throws Exception {
        DebitRequest request = new DebitRequest(merchantQRCode, merchantStoreMobileNo,
                customerMobileNo, amount, requestUUID, requestIndentityId);
        return client.initiateTransaction(request);
    }

    /**
     * Gets transaction status.
     *
     * @param requestUUID request UUID
     * @param ecomRequestId e-commerce request ID
     * @return TransactionStatusResponse
     * @throws Exception if request fails
     */
    public TransactionStatusResponse getTransactionStatus(String requestUUID, String ecomRequestId) throws Exception {
        TransactionStatusRequest request = new TransactionStatusRequest(requestUUID, ecomRequestId);
        return client.getTransactionStatus(request);
    }

    /**
     * Gets QR code.
     *
     * @param requestUUID request UUID
     * @param requestIndentityId request identity ID
     * @param qrCodeString QR code string
     * @param purposeOfTransaction purpose description
     * @param transactionAmount transaction amount
     * @param convenienceCharges convenience charges
     * @param isPercentageConvenienceCharges if charges are percentage
     * @return QRCodeResponse
     * @throws Exception if request fails
     */
    public QRCodeResponse getQRCode(String requestUUID, String requestIndentityId, String qrCodeString,
                                   String purposeOfTransaction, java.math.BigDecimal transactionAmount,
                                   java.math.BigDecimal convenienceCharges, boolean isPercentageConvenienceCharges) throws Exception {
        QRCodeRequest request = new QRCodeRequest(requestUUID, requestIndentityId, qrCodeString,
                purposeOfTransaction, transactionAmount, convenienceCharges, isPercentageConvenienceCharges);
        return client.getQRCode(request);
    }

    /**
     * Updates transaction status.
     *
     * @param requestUUID request UUID
     * @param requestId request ID
     * @param transactionId transaction ID
     * @param transactionStatusCode status code
     * @param transactionStatus status
     * @param statusDescription status description
     * @return StatusUpdateResponse
     * @throws Exception if request fails
     */
    public StatusUpdateResponse updateTransactionStatus(String requestUUID, String requestId, String transactionId,
                                                       String transactionStatusCode, String transactionStatus,
                                                       String statusDescription) throws Exception {
        StatusUpdateRequest request = new StatusUpdateRequest(requestUUID, requestId, transactionId,
                transactionStatusCode, transactionStatus, statusDescription);
        return client.updateTransactionStatus(request);
    }

    /**
     * Gets dynamic QR transaction status.
     *
     * @param requestUUID request UUID
     * @return DynamicQRStatusResponse
     * @throws Exception if request fails
     */
    public DynamicQRStatusResponse getDynamicQRTransactionStatus(String requestUUID) throws Exception {
        DynamicQRStatusRequest request = new DynamicQRStatusRequest(requestUUID);
        return client.getDynamicQRTransactionStatus(request);
    }
}
