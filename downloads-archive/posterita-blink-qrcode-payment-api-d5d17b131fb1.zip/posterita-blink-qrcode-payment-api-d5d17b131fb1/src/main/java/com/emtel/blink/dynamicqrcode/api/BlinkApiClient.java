package com.emtel.blink.dynamicqrcode.api;

import com.emtel.blink.dynamicqrcode.config.BlinkConfig;
import com.emtel.blink.dynamicqrcode.crypto.AESEncryptionUtil;
import com.emtel.blink.dynamicqrcode.model.*;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.time.Duration;
import java.util.logging.Logger;

import javax.net.ssl.SSLParameters;

import java.util.logging.Level;

import java.io.IOException;

/**
 * Main API client for Blink Payment System.
 * Handles authentication, encryption, and all API calls.
 */
public class BlinkApiClient {

    private static final Logger logger = Logger.getLogger(BlinkApiClient.class.getName());
    private static final String JSON_CONTENT_TYPE = "application/json; charset=utf-8";

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final BlinkConfig config;

    private String currentToken;
    private String currentSessionId;
    private long tokenExpiryTime;

    public BlinkApiClient(BlinkConfig config) {
        this.config = config;
        
        SSLParameters params = new SSLParameters();
	    params.setProtocols(new String[]{"TLSv1.2"});  // or {"TLSv1.3", "TLSv1.2"}
	    
        this.httpClient = HttpClient.newBuilder()
        		.sslParameters(params)
                .connectTimeout(Duration.ofSeconds(30))
                .build();
        
        this.objectMapper = new ObjectMapper();
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    /**
     * Creates a common HttpRequest.Builder with shared headers.
     */
    private HttpRequest.Builder createRequestBuilder(URI uri) {
        return HttpRequest.newBuilder()
                .uri(uri)
                .header("Content-Type", JSON_CONTENT_TYPE)
                .header("User-Agent", "okhttp/4.12.0");
    }

    /**
     * Authenticates and retrieves a token.
     *
     * @param requestIndentityId unique request identity ID
     * @return TokenResponse
     * @throws IOException if request fails
     * @throws Exception if encryption/decryption fails
     */
    public TokenResponse authenticate(String requestIndentityId) throws BlinkApiException, IOException, Exception {
        TokenRequest request = new TokenRequest(requestIndentityId, config.getUsername(), config.getPassword());

        String jsonRequest = objectMapper.writeValueAsString(request);
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getTokenUrl()))
                .header("Accept", "application/json, text/plain")
                .header("Accept-Encoding", "deflate")
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "Auth response: " + responseBody); 
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new BlinkApiException("Authentication failed", response.statusCode(), responseBody);
            }

                       

            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);

            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            
            //Bug fix: Need to parse response as string first
            //bug fix escape string
            if(decryptedData.indexOf("\"{") != -1) {
                
                decryptedData = objectMapper.readValue(decryptedData, String.class);
            }
            
            
            TokenData tokenData = objectMapper.readValue(decryptedData, TokenData.class);

            // Update current token and session
            this.currentToken = tokenData.getToken();
            this.currentSessionId = tokenData.getSessionId();
            this.tokenExpiryTime = System.currentTimeMillis() + (tokenData.getExpiry() * 60 * 1000);

            Status status = encryptedResponse.getStatus();
            return new TokenResponse(tokenData, status);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Checks if the current token is valid.
     *
     * @return true if token is valid
     */
    public boolean isTokenValid() {
        return currentToken != null && System.currentTimeMillis() < tokenExpiryTime;
    }

    /**
     * Initiates a debit transaction.
     *
     * @param debitRequest the debit request
     * @return DebitResponse
     * @throws IOException if request fails
     * @throws Exception if encryption/decryption fails
     */
    public DebitResponse initiateTransaction(DebitRequest debitRequest) throws IOException, Exception {
        if (!isTokenValid()) {
            throw new IllegalStateException("Token is invalid or expired. Please authenticate first.");
        }

        String jsonRequest = objectMapper.writeValueAsString(debitRequest);
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getDebitUrl()))
                .header("Authorization", currentToken)
                .header("SessionId", currentSessionId)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "Debit response: " + responseBody);
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("Debit request failed: " + response.statusCode());
            }

            

            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);

            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            DebitData debitData = objectMapper.readValue(decryptedData, DebitData.class);

            Status status = encryptedResponse.getStatus();
            return new DebitResponse(debitData, status);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Gets transaction status.
     *
     * @param statusRequest the status request
     * @return TransactionStatusResponse
     * @throws Exception 
     */
    public TransactionStatusResponse getTransactionStatus(TransactionStatusRequest statusRequest) throws Exception {
        if (!isTokenValid()) {
            throw new IllegalStateException("Token is invalid or expired. Please authenticate first.");
        }

        String jsonRequest = objectMapper.writeValueAsString(statusRequest);
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getTransactionStatusUrl()))
                .header("Authorization", currentToken)
                .header("SessionId", currentSessionId)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "Transaction status response: " + responseBody);
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("Transaction status request failed: " + response.statusCode());
            }
            
            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);

            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            
            //Bug fix: Need to parse response as string first
            //bug fix escape string
            if(decryptedData.indexOf("\"{") != -1) {
                
                decryptedData = objectMapper.readValue(decryptedData, String.class);
            }

            TransactionStatusData data = objectMapper.readValue(decryptedData, TransactionStatusData.class);
            Status status = encryptedResponse.getStatus();
            
            return new TransactionStatusResponse(data, status);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Gets QR Code.
     *
     * @param qrRequest the QR code request
     * @return QRCodeResponse
     * @throws Exception 
     */
    public QRCodeResponse getQRCode(QRCodeRequest qrRequest) throws Exception {
        if (!isTokenValid()) {
            throw new IllegalStateException("Token is invalid or expired. Please authenticate first.");
        }

        String jsonRequest = objectMapper.writeValueAsString(qrRequest);
        
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getQrCodeUrl()))
                .header("Authorization", currentToken)
                .header("SessionId", currentSessionId)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "QR Code response: " + responseBody);
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("QR Code request failed: " + response.statusCode());
            }
            
            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);
            
            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            logger.log(Level.FINE, "QR Code decrypted response: " + decryptedData);
            
            decryptedData = objectMapper.readValue(decryptedData, String.class);
            
            return objectMapper.readValue(decryptedData, QRCodeResponse.class);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Updates transaction status.
     *
     * @param statusUpdateRequest the status update request
     * @return StatusUpdateResponse
     * @throws IOException if request fails
     * @throws BlinkApiException 
     */
    public StatusUpdateResponse updateTransactionStatus(StatusUpdateRequest statusUpdateRequest) throws IOException, BlinkApiException {
        String jsonRequest = objectMapper.writeValueAsString(statusUpdateRequest);

        HttpRequest httpRequest = createRequestBuilder(URI.create(this.config.getStatusUpdateUrl()))
                .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "Status update response: " + responseBody);
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("Status update request failed: " + response.statusCode());
            }

            

            return objectMapper.readValue(responseBody, StatusUpdateResponse.class);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }

    /**
     * Gets dynamic QR transaction status.
     *
     * @param dynamicQrRequest the dynamic QR status request
     * @return DynamicQRStatusResponse
     * @throws Exception 
     */
    public DynamicQRStatusResponse getDynamicQRTransactionStatus(DynamicQRStatusRequest dynamicQrRequest) throws Exception {
        if (!isTokenValid()) {
            throw new IllegalStateException("Token is invalid or expired. Please authenticate first.");
        }

        String jsonRequest = objectMapper.writeValueAsString(dynamicQrRequest);
        
        String encryptedBody = AESEncryptionUtil.encrypt(jsonRequest, config.getAesKey(), config.getAesIv());

        String requestBody = "{\"body\":\"" + encryptedBody + "\"}";

        HttpRequest httpRequest = createRequestBuilder(URI.create(config.getDynamicQrStatusUrl()))
                .header("Authorization", currentToken)
                .header("SessionId", currentSessionId)
                .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
            
            String responseBody = response.body();
            logger.log(Level.FINE, "Dynamic QR status response: " + responseBody);            
            
            if(response.statusCode() >= 500) {
            	//server error
            	String errorMsg = "Blink Server Error: " + response.statusCode();
                logger.log(Level.SEVERE, errorMsg);
                throw new BlinkApiException(errorMsg, response.statusCode(), responseBody);
            }
            
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IOException("Dynamic QR status request failed: " + response.statusCode());
            }

            
            // Parse the encrypted response
            EncryptedResponse encryptedResponse = objectMapper.readValue(responseBody, EncryptedResponse.class);
            
            // Decrypt the data
            String decryptedData = AESEncryptionUtil.decrypt(encryptedResponse.getData(), config.getAesKey(), config.getAesIv());
            logger.log(Level.FINE, "DynamicQrRequest decrypted response: " + decryptedData);
            
            //Bug fix: Need to parse response as string first
            //bug fix escape string
            if(decryptedData.indexOf("\"{") != -1) {
                
                decryptedData = objectMapper.readValue(decryptedData, String.class);
            }
            
            DynamicQRStatusData data = null;
            
            if(decryptedData.equalsIgnoreCase("\"{}\"")) {
            }
            else
            {
            	data = objectMapper.readValue(decryptedData, DynamicQRStatusData.class);
            }

            return new DynamicQRStatusResponse(data, encryptedResponse.getStatus());
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Request interrupted", e);
        }
    }
}
