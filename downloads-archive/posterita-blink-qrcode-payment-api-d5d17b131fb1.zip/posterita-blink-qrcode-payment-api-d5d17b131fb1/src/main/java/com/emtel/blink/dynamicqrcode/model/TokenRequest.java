package com.emtel.blink.dynamicqrcode.model;

/**
 * Request model for Token API.
 */
public class TokenRequest {
    private String requestIndentityId;
    private String userName;
    private String password;

    public TokenRequest() {}

    public TokenRequest(String requestIndentityId, String userName, String password) {
        this.requestIndentityId = requestIndentityId;
        this.userName = userName;
        this.password = password;
    }

    public String getRequestIndentityId() {
        return requestIndentityId;
    }

    public void setRequestIndentityId(String requestIndentityId) {
        this.requestIndentityId = requestIndentityId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
