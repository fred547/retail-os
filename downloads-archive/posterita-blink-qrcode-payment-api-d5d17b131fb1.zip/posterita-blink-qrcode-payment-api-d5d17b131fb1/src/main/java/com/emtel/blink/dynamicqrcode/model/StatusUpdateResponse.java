package com.emtel.blink.dynamicqrcode.model;

/**
 * Response model for Status Update API.
 */
public class StatusUpdateResponse {
    private StatusUpdateData data;
    private Status status;

    public StatusUpdateResponse() {}

    public StatusUpdateResponse(StatusUpdateData data, Status status) {
        this.data = data;
        this.status = status;
    }

    public StatusUpdateData getData() {
        return data;
    }

    public void setData(StatusUpdateData data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
