package com.emtel.blink.dynamicqrcode.model;

public class DynamicQRStatusData {
    private String transactionDescription;
    private String transactionResponse;
    private boolean transactionStatus;
    private String transactionStatusCode;

    public DynamicQRStatusData() {}

    public DynamicQRStatusData(String transactionDescription, String transactionResponse,
                                  boolean transactionStatus, String transactionStatusCode) {
        this.transactionDescription = transactionDescription;
        this.transactionResponse = transactionResponse;
        this.transactionStatus = transactionStatus;
        this.transactionStatusCode = transactionStatusCode;
    }

    public String getTransactionDescription() {
        return transactionDescription;
    }

    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

    public String getTransactionResponse() {
        return transactionResponse;
    }

    public void setTransactionResponse(String transactionResponse) {
        this.transactionResponse = transactionResponse;
    }

    public boolean isTransactionStatus() {
        return transactionStatus;
    }

    public void setTransactionStatus(boolean transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public String getTransactionStatusCode() {
        return transactionStatusCode;
    }

    public void setTransactionStatusCode(String transactionStatusCode) {
        this.transactionStatusCode = transactionStatusCode;
    }
}
