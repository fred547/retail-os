package com.emtel.blink.dynamicqrcode.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Configuration holder for Blink API. Supports loading from a properties file
 * with caching and reload-on-demand capability.
 */
public class BlinkConfig {

    private boolean isProduction;

    private String tokenUrl;
    private String debitUrl;
    private String transactionStatusUrl;
    private String qrCodeUrl;
    private String dynamicQrStatusUrl;

    private String aesKey;
    private String aesIv;
    private String username;
    private String password;

    private String statusUpdateUrl;

    private static BlinkConfig instance;
    private static String configPath;
    private static final Object lock = new Object();

    private BlinkConfig() {
    }

    // === Public Getters ===
    public boolean isProduction() { return isProduction; }
    public String getTokenUrl() { return tokenUrl; }
    public String getDebitUrl() { return debitUrl; }
    public String getTransactionStatusUrl() { return transactionStatusUrl; }
    public String getQrCodeUrl() { return qrCodeUrl; }
    public String getDynamicQrStatusUrl() { return dynamicQrStatusUrl; }
    public String getAesKey() { return aesKey; }
    public String getAesIv() { return aesIv; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getStatusUpdateUrl() { return statusUpdateUrl; }

    // === Static Accessors ===

    /**
     * Get the currently loaded config instance.
     * Must call setConfigPath(...) first before using this.
     *
     * @return BlinkConfig instance
     * @throws IllegalStateException if config was not yet loaded
     */
    public static BlinkConfig getConfig() {
        synchronized (lock) {
            if (instance == null) {
                if (configPath == null) {
                    throw new IllegalStateException("Config path not set. Call setConfigPath(...) first.");
                }
                try {
                    loadFromFile(configPath);
                } catch (IOException e) {
                    throw new RuntimeException("Failed to load BlinkConfig from file: " + configPath, e);
                }
            }
            return instance;
        }
    }

    /**
     * Sets the config file path to use for loading.
     * This must be called once before calling getConfig().
     *
     * @param path path to the properties file
     */
    public static void setConfigPath(String path) {
        synchronized (lock) {
            configPath = path;
        }
    }

    /**
     * Load or reload the configuration from file.
     *
     * @param filePath path to the file
     * @return reloaded config
     * @throws IOException if reading file fails
     */
    public static BlinkConfig loadFromFile(String filePath) throws IOException {
        synchronized (lock) {
            Properties props = new Properties();
            try (InputStream input = new FileInputStream(filePath)) {
                props.load(input);
            }

            BlinkConfig config = new BlinkConfig();
            config.isProduction = Boolean.parseBoolean(props.getProperty("blink.is-production"));
            config.tokenUrl = props.getProperty("blink.token-url");
            config.debitUrl = props.getProperty("blink.debit-url");
            config.transactionStatusUrl = props.getProperty("blink.transaction-status-url");
            config.qrCodeUrl = props.getProperty("blink.qr-code-url");
            config.dynamicQrStatusUrl = props.getProperty("blink.dynamic-qr-status-url");

            config.aesKey = props.getProperty("blink.aes-key");
            config.aesIv = props.getProperty("blink.aes-iv");
            config.username = props.getProperty("blink.username");
            config.password = props.getProperty("blink.password");

            config.statusUpdateUrl = props.getProperty("blink.status-update-url");

            instance = config;
            configPath = filePath;

            return config;
        }
    }

    /**
     * Reloads the config from the previously set file path.
     */
    public static void reload() throws IOException {
        synchronized (lock) {
            if (configPath == null) {
                throw new IllegalStateException("Cannot reload config: configPath is not set.");
            }
            loadFromFile(configPath);
        }
    }

    /**
     * Clears the current cached config and path (for testing or restart).
     */
    public static void reset() {
        synchronized (lock) {
            instance = null;
            configPath = null;
        }
    }
}
