package com.emtel.blink.dynamicqrcode.model;

/**
 * Response model for Get Dynamic QR Transaction Status API.
 */
public class DynamicQRStatusResponse {
	private DynamicQRStatusData data;
    private Status status;
    
    public DynamicQRStatusResponse() {}
    
    public DynamicQRStatusResponse(DynamicQRStatusData data, Status status) {
    	this.data = data;
    	this.status = status;
    }

	public DynamicQRStatusData getData() {
		return data;
	}

	public void setData(DynamicQRStatusData data) {
		this.data = data;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}    
	
}
