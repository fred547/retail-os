package com.emtel.blink.dynamicqrcode.model;

/**
 * Response model for Get QR Code API.
 */
public class QRCodeResponse {
    private QRCodeData data;
    private Status status;

    public QRCodeResponse() {}

    public QRCodeResponse(QRCodeData data, Status status) {
        this.data = data;
        this.status = status;
    }

    public QRCodeData getData() {
        return data;
    }

    public void setData(QRCodeData data) {
        this.data = data;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
