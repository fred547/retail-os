package com.emtel.blink.dynamicqrcode.model;

/**
 * Data model for Token response.
 */
public class TokenData {
    private String token;
    private String sessionId;
    private int expiry;

    public TokenData() {}

    public TokenData(String token, String sessionId, int expiry) {
        this.token = token;
        this.sessionId = sessionId;
        this.expiry = expiry;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public int getExpiry() {
        return expiry;
    }

    public void setExpiry(int expiry) {
        this.expiry = expiry;
    }
}
