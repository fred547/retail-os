package com.emtel.blink.dynamicqrcode.model;

/**
 * Request model for Transaction Status API.
 */
public class TransactionStatusRequest {
    private String requestUUID;
    private String ecomRequestId;

    public TransactionStatusRequest() {}

    public TransactionStatusRequest(String requestUUID, String ecomRequestId) {
        this.requestUUID = requestUUID;
        this.ecomRequestId = ecomRequestId;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getEcomRequestId() {
        return ecomRequestId;
    }

    public void setEcomRequestId(String ecomRequestId) {
        this.ecomRequestId = ecomRequestId;
    }
}
