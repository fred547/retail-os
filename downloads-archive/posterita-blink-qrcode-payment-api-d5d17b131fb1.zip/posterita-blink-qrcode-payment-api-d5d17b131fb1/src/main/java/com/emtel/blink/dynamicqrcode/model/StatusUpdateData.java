package com.emtel.blink.dynamicqrcode.model;

/**
 * Data model for Status Update response (empty).
 */
public class StatusUpdateData {
    // Empty as per API
}
