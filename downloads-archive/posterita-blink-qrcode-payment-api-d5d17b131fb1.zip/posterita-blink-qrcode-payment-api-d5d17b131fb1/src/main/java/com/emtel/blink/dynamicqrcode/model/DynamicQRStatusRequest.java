package com.emtel.blink.dynamicqrcode.model;

/**
 * Request model for Get Dynamic QR Transaction Status API.
 */
public class DynamicQRStatusRequest {
    private String requestUUID;

    public DynamicQRStatusRequest() {}

    public DynamicQRStatusRequest(String requestUUID) {
        this.requestUUID = requestUUID;
    }

    public String getRequestUUID() {
        return requestUUID;
    }

    public void setRequestUUID(String requestUUID) {
        this.requestUUID = requestUUID;
    }
}
