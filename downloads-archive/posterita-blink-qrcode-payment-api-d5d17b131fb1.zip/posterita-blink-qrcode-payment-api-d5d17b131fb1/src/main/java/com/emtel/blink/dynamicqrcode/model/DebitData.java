package com.emtel.blink.dynamicqrcode.model;

/**
 * Data model for Debit response.
 */
public class DebitData {
    private String requestId;

    public DebitData() {}

    public DebitData(String requestId) {
        this.requestId = requestId;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }
}
