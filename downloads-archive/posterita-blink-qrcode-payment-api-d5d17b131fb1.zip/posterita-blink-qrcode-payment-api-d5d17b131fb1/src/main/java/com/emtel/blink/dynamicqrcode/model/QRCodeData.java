package com.emtel.blink.dynamicqrcode.model;

/**
 * Data model for QR Code response.
 */
public class QRCodeData {
    private String qrCodeString;

    public QRCodeData() {}

    public QRCodeData(String qrCodeString) {
        this.qrCodeString = qrCodeString;
    }

    public String getQrCodeString() {
        return qrCodeString;
    }

    public void setQrCodeString(String qrCodeString) {
        this.qrCodeString = qrCodeString;
    }
}
