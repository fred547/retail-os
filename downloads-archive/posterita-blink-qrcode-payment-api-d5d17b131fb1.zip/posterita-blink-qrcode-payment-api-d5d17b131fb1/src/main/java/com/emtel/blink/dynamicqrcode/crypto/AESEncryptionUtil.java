package com.emtel.blink.dynamicqrcode.crypto;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Base64;

/**
 * Utility class for AES encryption/decryption as per Blink API specification.
 * Uses AES/CBC/PKCS5Padding with Base64 encoding.
 */
public class AESEncryptionUtil {

    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";

    /**
     * Encrypts the given plain text using AES.
     *
     * @param plainText the text to encrypt
     * @param key       the AES key (32 characters)
     * @param iv        the initialization vector (16 characters)
     * @return Base64 encoded encrypted string
     * @throws Exception if encryption fails
     */
    public static String encrypt(String plainText, String key, String iv) throws Exception {
        if (plainText == null || plainText.isEmpty()) {
            throw new IllegalArgumentException("Plain text cannot be null or empty");
        }
        if (key == null || key.length() != 32) {
            throw new IllegalArgumentException("Key must be 32 characters long");
        }
        if (iv == null || iv.length() != 16) {
            throw new IllegalArgumentException("IV must be 16 characters long");
        }

        Key secretKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv.getBytes(StandardCharsets.UTF_8));

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);

        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(encryptedBytes);
    }

    /**
     * Decrypts the given Base64 encoded encrypted text using AES.
     *
     * @param encryptedText the Base64 encoded encrypted text
     * @param key           the AES key (32 characters)
     * @param iv            the initialization vector (16 characters)
     * @return decrypted plain text
     * @throws Exception if decryption fails
     */
    public static String decrypt(String encryptedText, String key, String iv) throws Exception {
        if (encryptedText == null || encryptedText.isEmpty()) {
            throw new IllegalArgumentException("Encrypted text cannot be null or empty");
        }
        if (key == null || key.length() != 32) {
            throw new IllegalArgumentException("Key must be 32 characters long");
        }
        if (iv == null || iv.length() != 16) {
            throw new IllegalArgumentException("IV must be 16 characters long");
        }

        Key secretKey = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(iv.getBytes(StandardCharsets.UTF_8));

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);

        byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
        byte[] decryptedBytes = cipher.doFinal(decodedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }
}
