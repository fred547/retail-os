package com.emtel.blink.dynamicqrcode.config;

import org.junit.jupiter.api.*;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class BlinkConfigTest {

    private static Path tempFile;

    @BeforeAll
    static void createTempPropertiesFile() throws IOException {
        tempFile = Files.createTempFile("blink-config-test", ".properties");

        try (FileWriter writer = new FileWriter(tempFile.toFile())) {
            writer.write("blink.is-production=true\n");
            writer.write("blink.token-url=https://api.example.com/token\n");
            writer.write("blink.debit-url=https://api.example.com/debit\n");
            writer.write("blink.transaction-status-url=https://api.example.com/status\n");
            writer.write("blink.qr-code-url=https://api.example.com/qrcode\n");
            writer.write("blink.dynamic-qr-status-url=https://api.example.com/qrstatus\n");

            writer.write("blink.aes-key=1234567890abcdef1234567890abcdef\n");
            writer.write("blink.aes-iv=abcdef1234567890\n");
            writer.write("blink.username=testuser\n");
            writer.write("blink.password=testpassword\n");

            writer.write("blink.status-update-url=https://partner.example.com/status-update\n");
        }
    }

    @AfterEach
    void cleanupEach() {
        BlinkConfig.reset(); // Clear cached instance between tests
    }

    @AfterAll
    static void cleanupTempFile() throws IOException {
        Files.deleteIfExists(tempFile);
    }

    @Test
    void testLoadAndVerifyAllProperties() throws IOException {
        BlinkConfig config = BlinkConfig.loadFromFile(tempFile.toString());

        assertNotNull(config);

        // Verify all fields are loaded and correct
        assertTrue(config.isProduction());

        assertEquals("https://api.example.com/token", config.getTokenUrl());
        assertEquals("https://api.example.com/debit", config.getDebitUrl());
        assertEquals("https://api.example.com/status", config.getTransactionStatusUrl());
        assertEquals("https://api.example.com/qrcode", config.getQrCodeUrl());
        assertEquals("https://api.example.com/qrstatus", config.getDynamicQrStatusUrl());

        assertEquals("1234567890abcdef1234567890abcdef", config.getAesKey());
        assertEquals("abcdef1234567890", config.getAesIv());
        assertEquals("testuser", config.getUsername());
        assertEquals("testpassword", config.getPassword());

        assertEquals("https://partner.example.com/status-update", config.getStatusUpdateUrl());
    }

    @Test
    void testForceReloadConfig() throws IOException {
        // First load
        BlinkConfig config1 = BlinkConfig.loadFromFile(tempFile.toString());

        // Modify file content
        try (FileWriter writer = new FileWriter(tempFile.toFile())) {
            writer.write("blink.is-production=false\n");
            writer.write("blink.token-url=https://changed.example.com/token\n");
            writer.write("blink.debit-url=https://changed.example.com/debit\n");
            writer.write("blink.transaction-status-url=https://changed.example.com/status\n");
            writer.write("blink.qr-code-url=https://changed.example.com/qrcode\n");
            writer.write("blink.dynamic-qr-status-url=https://changed.example.com/qrstatus\n");
            writer.write("blink.aes-key=changedkey\n");
            writer.write("blink.aes-iv=changediv\n");
            writer.write("blink.username=changeduser\n");
            writer.write("blink.password=changedpass\n");
            writer.write("blink.status-update-url=https://changed.example.com/status-update\n");
        }

        BlinkConfig.setConfigPath(tempFile.toString());
        BlinkConfig.reload();
        BlinkConfig config2 = BlinkConfig.getConfig();

        assertNotSame(config1, config2);
        assertFalse(config2.isProduction());
        assertEquals("https://changed.example.com/token", config2.getTokenUrl());
        assertEquals("changeduser", config2.getUsername());
    }

    @Test
    void testResetClearsInstance() {
        BlinkConfig.setConfigPath(tempFile.toString());
        BlinkConfig.getConfig(); // Load once

        BlinkConfig.reset();

        IllegalStateException exception = assertThrows(IllegalStateException.class, BlinkConfig::getConfig);
        assertEquals("Config path not set. Call setConfigPath(...) first.", exception.getMessage());
    }
}

