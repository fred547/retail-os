package com.emtel.blink.dynamicqrcode;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.emtel.blink.dynamicqrcode.BlinkPaymentApi;
import com.emtel.blink.dynamicqrcode.api.BlinkApiClient;
import com.emtel.blink.dynamicqrcode.model.*;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;

/**
 * Integration tests for BlinkPaymentApi using Mockito mocks.
 * These tests mock the BlinkApiClient to avoid real HTTP calls.
 */
@ExtendWith(MockitoExtension.class)
public class BlinkPaymentApiIntegrationTest {

    @Mock
    private BlinkApiClient mockApiClient;

    @InjectMocks
    private BlinkPaymentApi blinkPaymentApi;

    @Test
    public void testRealAuthentication() throws Exception {
        // Create mock response
        TokenData mockTokenData = new TokenData();
        mockTokenData.setToken("mock-token-" + System.currentTimeMillis());
        mockTokenData.setSessionId("mock-session-" + System.currentTimeMillis());
        mockTokenData.setExpiry(900); // 15 minutes

        Status mockStatus = new Status();
        mockStatus.setSuccess(true);
        mockStatus.setMessage("Success");
        mockStatus.setStatusCode("SUCCESS");

        TokenResponse mockResponse = new TokenResponse(mockTokenData, mockStatus);

        // Mock the API call
        lenient().when(mockApiClient.authenticate(anyString())).thenReturn(mockResponse);

        // Test authentication
        String requestId = "TEST" + System.currentTimeMillis();
        TokenResponse response = blinkPaymentApi.authenticate(requestId);

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().getToken());
        assertNotNull(response.getData().getSessionId());
        assertTrue(response.getData().getExpiry() > 0);
        assertTrue(response.getStatus().isSuccess());

        System.out.println("Authentication successful:");
        System.out.println("Token: " + response.getData().getToken());
        System.out.println("Session ID: " + response.getData().getSessionId());
    }

    @Test
    public void testRealQRCodeGeneration() throws Exception {
        // Create mock auth response
        TokenData mockTokenData = new TokenData();
        mockTokenData.setToken("mock-token-" + System.currentTimeMillis());
        mockTokenData.setSessionId("mock-session-" + System.currentTimeMillis());
        mockTokenData.setExpiry(900);

        Status mockStatus = new Status();
        mockStatus.setSuccess(true);

        TokenResponse mockAuthResponse = new TokenResponse(mockTokenData, mockStatus);

        // Create mock QR response
        QRCodeData mockQrData = new QRCodeData();
        mockQrData.setQrCodeString("00020101021226610009mu.maucas0112EMFSMUM0XXXX020910084300103150000000000105765204569953034805405100.05802MU5917Posterita Testing6009Mauritius62670208545631610515QR175688317524507033430825Integration Test Transact6304B274");

        QRCodeResponse mockQrResponse = new QRCodeResponse(mockQrData, mockStatus);

        // Mock the API calls
        lenient().when(mockApiClient.authenticate(anyString())).thenReturn(mockAuthResponse);
        lenient().when(mockApiClient.getQRCode(any(QRCodeRequest.class))).thenReturn(mockQrResponse);

        // Test QR code generation
        String qrRequestUUID = "QR" + System.currentTimeMillis();
        String qrCodeString = "00020101021126610009mu.maucas0112EMFSMUM0XXXX020910084300103150000000000105765204569953034805802MU5917Posterita Testing6009Mauritius621902085515546007033436304A363";

        QRCodeResponse response = blinkPaymentApi.getQRCode(
            qrRequestUUID,
            "TEST" + System.currentTimeMillis(),
            qrCodeString,
            "Integration Test Transaction",
            new BigDecimal("100.00"),
            BigDecimal.ZERO,
            false
        );

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().getQrCodeString());
        assertTrue(response.getStatus().isSuccess());

        System.out.println("QR Code generated successfully:");
        System.out.println("QR Code: " + response.getData().getQrCodeString());
    }

    @Test
    public void testRealTransactionStatus() throws Exception {
        // Create mock auth response
        TokenData mockTokenData = new TokenData();
        mockTokenData.setToken("mock-token-" + System.currentTimeMillis());
        mockTokenData.setSessionId("mock-session-" + System.currentTimeMillis());
        mockTokenData.setExpiry(900);

        Status mockStatus = new Status();
        mockStatus.setSuccess(true);

        TokenResponse mockAuthResponse = new TokenResponse(mockTokenData, mockStatus);

        // Create mock transaction status response
        TransactionStatusData mockTxnData = new TransactionStatusData();
        mockTxnData.setTransactionId("ECOMTXN2022071112051159");
        mockTxnData.setTransactionResponse("Transaction completed successfully");
        mockTxnData.setTransactionStatusCode("SUCCESS");

        TransactionStatusResponse mockTxnResponse = new TransactionStatusResponse(mockTxnData, mockStatus);

        // Mock the API calls
        lenient().when(mockApiClient.authenticate(anyString())).thenReturn(mockAuthResponse);
        lenient().when(mockApiClient.getTransactionStatus(any(TransactionStatusRequest.class))).thenReturn(mockTxnResponse);

        // Test transaction status with a known test transaction ID
        String testTransactionId = "ECOMTXN2022071112051159"; // Example from docs

        try {
            TransactionStatusResponse response = blinkPaymentApi.getTransactionStatus(
                "STATUS" + System.currentTimeMillis(),
                testTransactionId
            );

            assertNotNull(response);
            assertNotNull(response.getData());
            assertNotNull(response.getStatus());

            System.out.println("Transaction Status:");
            System.out.println("Transaction ID: " + response.getData().getTransactionId());
            System.out.println("Status: " + response.getData().getTransactionResponse());
            System.out.println("Status Code: " + response.getData().getTransactionStatusCode());

        } catch (Exception e) {
            // Transaction might not exist, which is expected for integration testing
            System.out.println("Transaction status test failed (expected for new transactions): " + e.getMessage());
        }
    }

    @Test
    public void testRealDynamicQRStatus() throws Exception {
        // Create mock auth response
        TokenData mockTokenData = new TokenData();
        mockTokenData.setToken("mock-token-" + System.currentTimeMillis());
        mockTokenData.setSessionId("mock-session-" + System.currentTimeMillis());
        mockTokenData.setExpiry(900);

        Status mockStatus = new Status();
        mockStatus.setSuccess(true);

        TokenResponse mockAuthResponse = new TokenResponse(mockTokenData, mockStatus);

        // Create mock dynamic QR status response
        DynamicQRStatusResponse mockDynamicResponse = new DynamicQRStatusResponse();
        
        DynamicQRStatusData data = new DynamicQRStatusData();
        data.setTransactionResponse("Dynamic QR transaction completed");
        data.setTransactionStatus(true);
        data.setTransactionStatusCode("SUCCESS");
        data.setTransactionDescription("Transaction processed successfully");
        
        mockDynamicResponse.setData(data);

        // Mock the API calls
        lenient().when(mockApiClient.authenticate(anyString())).thenReturn(mockAuthResponse);
        lenient().when(mockApiClient.getDynamicQRTransactionStatus(any(DynamicQRStatusRequest.class))).thenReturn(mockDynamicResponse);

        // Test dynamic QR status
        String qrRequestUUID = "DYNAMIC" + System.currentTimeMillis();

        try {
            DynamicQRStatusResponse response = blinkPaymentApi.getDynamicQRTransactionStatus(qrRequestUUID);

            assertNotNull(response);
            
            data = response.getData();
            
            assertNotNull(data.getTransactionResponse());

            System.out.println("Dynamic QR Status:");
            System.out.println("Response: " + data.getTransactionResponse());
            System.out.println("Status: " + data.isTransactionStatus());
            System.out.println("Status Code: " + data.getTransactionStatusCode());

        } catch (Exception e) {
            System.out.println("Dynamic QR status test failed: " + e.getMessage());
        }
    }

    /**
     * WARNING: This test will attempt to initiate a real transaction.
     * Only run this if you have test funds and understand the consequences.
     * The transaction amount should be minimal for testing purposes.
     */
    @Test
    @Disabled("Real transaction test - extremely dangerous, only run with test funds")
    public void testRealTransactionInitiation() throws Exception {
        // Create mock auth response
        TokenData mockTokenData = new TokenData();
        mockTokenData.setToken("mock-token-" + System.currentTimeMillis());
        mockTokenData.setSessionId("mock-session-" + System.currentTimeMillis());
        mockTokenData.setExpiry(900);

        Status mockStatus = new Status();
        mockStatus.setSuccess(true);

        TokenResponse mockAuthResponse = new TokenResponse(mockTokenData, mockStatus);

        // Create mock debit response
        DebitData mockDebitData = new DebitData();
        mockDebitData.setRequestId("TXN" + System.currentTimeMillis());

        DebitResponse mockDebitResponse = new DebitResponse(mockDebitData, mockStatus);

        // Mock the API calls
        lenient().when(mockApiClient.authenticate(anyString())).thenReturn(mockAuthResponse);
        lenient().when(mockApiClient.initiateTransaction(any(DebitRequest.class))).thenReturn(mockDebitResponse);

        // Test transaction initiation with minimal amount
        String merchantQR = "00020101021126610009mu.maucas0112EMFSMUM0XXXX020910002300303150000000000000165202AA53034805802MU5910Test Store6010Port Louis62170208523232880701363042DFB";
        String merchantMobile = "533233323";
        String customerMobile = "58580000"; // Use a test mobile number
        BigDecimal amount = new BigDecimal("1.00"); // Minimal test amount
        String txnRequestUUID = "TXN" + System.currentTimeMillis();

        DebitResponse response = blinkPaymentApi.initiateTransaction(
            merchantQR,
            merchantMobile,
            customerMobile,
            amount,
            txnRequestUUID,
            "TEST" + System.currentTimeMillis()
        );

        assertNotNull(response);
        assertNotNull(response.getStatus());

        if (response.getStatus().isSuccess()) {
            System.out.println("Transaction initiated successfully:");
            System.out.println("Request ID: " + response.getData().getRequestId());
        } else {
            System.out.println("Transaction failed:");
            System.out.println("Error: " + response.getStatus().getMessage());
            System.out.println("Status Code: " + response.getStatus().getStatusCode());
        }
    }
}
