package com.emtel.blink.dynamicqrcode;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.emtel.blink.dynamicqrcode.BlinkPaymentApi;
import com.emtel.blink.dynamicqrcode.config.BlinkConfig;
import com.emtel.blink.dynamicqrcode.model.*;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for BlinkPaymentApi that make real API calls.
 * These tests require network connectivity and valid API credentials.
 * Use UAT environment for testing.
 *
 * NOTE: These tests are disabled by default to avoid accidental execution.
 * Remove @Disabled annotation to run integration tests.
 */
@Disabled("Integration tests - remove @Disabled to run against real API")
public class LiveTest {
	
	static BlinkConfig config;
	static BlinkPaymentApi api;
	
	@BeforeAll
	public static void setup() throws IOException {
		BlinkConfig.setConfigPath("src/test/resources/blink-uat.properties");
		config = BlinkConfig.getConfig();
		api = new BlinkPaymentApi(config);
	}
	
	@Test
	public void testConfig() {
		assertEquals(config.isProduction(), false);
	}

    @Test
    public void testRealAuthentication() throws Exception {
        // Test authentication with real API
        String requestId = "TEST" + System.currentTimeMillis();

        TokenResponse response = api.authenticate(requestId);

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().getToken());
        assertNotNull(response.getData().getSessionId());
        assertTrue(response.getData().getExpiry() > 0);
        assertTrue(response.getStatus().isSuccess());

        System.out.println("Authentication successful:");
        System.out.println("Token: " + response.getData().getToken());
        System.out.println("Session ID: " + response.getData().getSessionId());
    }

    @Test
    public void testRealQRCodeGeneration() throws Exception {
        // First authenticate
        String requestId = "TEST" + System.currentTimeMillis();
        TokenResponse authResponse = api.authenticate(requestId);
        assertTrue(authResponse.getStatus().isSuccess());

        // Test QR code generation
        String qrRequestUUID = "QR" + System.currentTimeMillis();
        String qrCodeString = "00020101021126610009mu.maucas0112EMFSMUM0XXXX020910084300103150000000000105765204569953034805802MU5917Posterita Testing6009Mauritius621902085515546007033436304A363";
		

        QRCodeResponse response = api.getQRCode(
            qrRequestUUID,
            requestId,
            qrCodeString,
            "Integration Test Transaction",
            new BigDecimal("100.00"),
            BigDecimal.ZERO,
            false
        );

        assertNotNull(response);
        assertNotNull(response.getData());
        assertNotNull(response.getData().getQrCodeString());
        assertTrue(response.getStatus().isSuccess());

        System.out.println("QR Code generated successfully:");
        System.out.println("QR Code: " + response.getData().getQrCodeString());
    }

    @Test
    public void testRealTransactionStatus() throws Exception {
        // First authenticate
        String requestId = "TEST" + System.currentTimeMillis();
        TokenResponse authResponse = api.authenticate(requestId);
        assertTrue(authResponse.getStatus().isSuccess());

        // Test transaction status with a known test transaction ID
        // Note: This requires a valid transaction ID from previous tests
        String testTransactionId = "ECOMTXN2022071112051159"; // Example from docs

        try {
            TransactionStatusResponse response = api.getTransactionStatus(
                "STATUS" + System.currentTimeMillis(),
                testTransactionId
            );

            assertNotNull(response);
            assertNotNull(response.getData());
            assertNotNull(response.getStatus());

            System.out.println("Transaction Status:");
            System.out.println("Transaction ID: " + response.getData().getTransactionId());
            System.out.println("Status: " + response.getData().getTransactionResponse());
            System.out.println("Status Code: " + response.getData().getTransactionStatusCode());

        } catch (Exception e) {
            // Transaction might not exist, which is expected for integration testing
            System.out.println("Transaction status test failed (expected for new transactions): " + e.getMessage());
        }
    }

    @Test
    public void testRealDynamicQRStatus() throws Exception {
    	// First authenticate
        String requestId = "TEST" + System.currentTimeMillis();
        TokenResponse authResponse = api.authenticate(requestId);
        assertTrue(authResponse.getStatus().isSuccess());

        // Test QR code generation
        String qrRequestUUID = "100081021758017813310";
        

        try {
            DynamicQRStatusResponse dynamicQRStatusResponse = api.getDynamicQRTransactionStatus(qrRequestUUID);

            assertNotNull(dynamicQRStatusResponse);
            
            DynamicQRStatusData data = dynamicQRStatusResponse.getData();
            
            assertNotNull(data);

            System.out.println("Dynamic QR Status:");
            System.out.println("Response: " + data.getTransactionResponse());
            System.out.println("Status: " + data.isTransactionStatus());
            System.out.println("Status Code: " + data.getTransactionStatusCode());

        } catch (Exception e) {
            System.out.println("Dynamic QR status test failed: " + e.getMessage());
        }
    }

    /**
     * WARNING: This test will attempt to initiate a real transaction.
     * Only run this if you have test funds and understand the consequences.
     * The transaction amount should be minimal for testing purposes.
     */
    @Test
    @Disabled("Real transaction test - extremely dangerous, only run with test funds")
    public void testRealTransactionInitiation() throws Exception {
        // First authenticate
        String requestId = "TEST" + System.currentTimeMillis();
        TokenResponse authResponse = api.authenticate(requestId);
        assertTrue(authResponse.getStatus().isSuccess());

        // Test transaction initiation with minimal amount
        String merchantQR = "00020101021126610009mu.maucas0112EMFSMUM0XXXX020910002300303150000000000000165202AA53034805802MU5910Test Store6010Port Louis62170208523232880701363042DFB";
        String merchantMobile = "533233323";
        String customerMobile = "58580000"; // Use a test mobile number
        BigDecimal amount = new BigDecimal("1.00"); // Minimal test amount
        String txnRequestUUID = "TXN" + System.currentTimeMillis();

        DebitResponse response = api.initiateTransaction(
            merchantQR,
            merchantMobile,
            customerMobile,
            amount,
            txnRequestUUID,
            requestId
        );

        assertNotNull(response);
        assertNotNull(response.getStatus());

        if (response.getStatus().isSuccess()) {
            System.out.println("Transaction initiated successfully:");
            System.out.println("Request ID: " + response.getData().getRequestId());
        } else {
            System.out.println("Transaction failed:");
            System.out.println("Error: " + response.getStatus().getMessage());
            System.out.println("Status Code: " + response.getStatus().getStatusCode());
        }
    }
}
