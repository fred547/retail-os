package com.emtel.blink.dynamicqrcode.crypto;

import org.junit.jupiter.api.Test;

import com.emtel.blink.dynamicqrcode.crypto.AESEncryptionUtil;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for AESEncryptionUtil.
 */
public class AESEncryptionUtilTest {

    private static final String TEST_KEY = "s3c0xCNrjnYp6r5F8cKwN0w3q6UCMogf"; // 32 chars
    private static final String TEST_IV = "mUhDI03yKQgJg3q7"; // 16 chars
    private static final String PLAIN_TEXT = "Hello, World!";

    @Test
    public void testEncryptDecrypt() throws Exception {
        // Encrypt
        String encrypted = AESEncryptionUtil.encrypt(PLAIN_TEXT, TEST_KEY, TEST_IV);
        assertNotNull(encrypted);
        assertNotEquals(PLAIN_TEXT, encrypted);

        // Decrypt
        String decrypted = AESEncryptionUtil.decrypt(encrypted, TEST_KEY, TEST_IV);
        assertEquals(PLAIN_TEXT, decrypted);
    }

    @Test
    public void testEncryptWithNullPlainText() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            AESEncryptionUtil.encrypt(null, TEST_KEY, TEST_IV);
        });
        assertEquals("Plain text cannot be null or empty", exception.getMessage());
    }

    @Test
    public void testEncryptWithInvalidKeyLength() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            AESEncryptionUtil.encrypt(PLAIN_TEXT, "shortkey", TEST_IV);
        });
        assertEquals("Key must be 32 characters long", exception.getMessage());
    }

    @Test
    public void testEncryptWithInvalidIvLength() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            AESEncryptionUtil.encrypt(PLAIN_TEXT, TEST_KEY, "shortiv");
        });
        assertEquals("IV must be 16 characters long", exception.getMessage());
    }
}
