package com.emtel.blink.dynamicqrcode;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.emtel.blink.dynamicqrcode.BlinkPaymentApi;
import com.emtel.blink.dynamicqrcode.api.BlinkApiClient;
import com.emtel.blink.dynamicqrcode.model.*;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for BlinkPaymentApi facade.
 */
public class BlinkPaymentApiTest {

    @Mock
    private BlinkApiClient mockClient;

    private BlinkPaymentApi api;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        api = new BlinkPaymentApi(mockClient);
    }

    @Test
    public void testAuthenticate() throws Exception {
        // Given
        String requestId = "TEST123";
        TokenResponse expectedResponse = new TokenResponse(
            new TokenData("token123", "session123", 5),
            new Status(true, null, "0")
        );
        when(mockClient.authenticate(requestId)).thenReturn(expectedResponse);

        // When
        TokenResponse response = api.authenticate(requestId);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).authenticate(requestId);
    }

    @Test
    public void testInitiateTransaction() throws Exception {
        // Given
        String merchantQR = "qr123";
        String merchantMobile = "533233323";
        String customerMobile = "58580000";
        BigDecimal amount = new BigDecimal("100.00");
        String requestUUID = "uuid123";
        String requestId = "req123";

        DebitResponse expectedResponse = new DebitResponse(
            new DebitData("TXN123"),
            new Status(true, "Payment successfully processed", "0")
        );

        when(mockClient.initiateTransaction(any(DebitRequest.class))).thenReturn(expectedResponse);

        // When
        DebitResponse response = api.initiateTransaction(merchantQR, merchantMobile, customerMobile,
                amount, requestUUID, requestId);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).initiateTransaction(any(DebitRequest.class));
    }

    @Test
    public void testGetTransactionStatus() throws Exception {
        // Given
        String requestUUID = "uuid123";
        String ecomRequestId = "ecom123";

        TransactionStatusResponse expectedResponse = new TransactionStatusResponse(
            new TransactionStatusData("TXN123", "ACSP", "Success", true, "ACSP"),
            new Status(true, "Success", "0")
        );

        when(mockClient.getTransactionStatus(any(TransactionStatusRequest.class))).thenReturn(expectedResponse);

        // When
        TransactionStatusResponse response = api.getTransactionStatus(requestUUID, ecomRequestId);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).getTransactionStatus(any(TransactionStatusRequest.class));
    }

    @Test
    public void testGetQRCode() throws Exception {
        // Given
        String requestUUID = "uuid123";
        String requestId = "req123";
        String qrCodeString = "qrstring";
        String purpose = "Test";
        BigDecimal amount = new BigDecimal("234.60");
        BigDecimal charges = BigDecimal.ZERO;
        boolean isPercentage = false;

        QRCodeResponse expectedResponse = new QRCodeResponse(
            new QRCodeData("newQRCode"),
            new Status(true, null, null)
        );

        when(mockClient.getQRCode(any(QRCodeRequest.class))).thenReturn(expectedResponse);

        // When
        QRCodeResponse response = api.getQRCode(requestUUID, requestId, qrCodeString, purpose,
                amount, charges, isPercentage);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).getQRCode(any(QRCodeRequest.class));
    }

    @Test
    public void testUpdateTransactionStatus() throws Exception {
        // Given
        String requestUUID = "uuid123";
        String requestId = "req123";
        String transactionId = "txn123";
        String statusCode = "ACSP";
        String status = "Success";
        String description = "Completed";

        StatusUpdateResponse expectedResponse = new StatusUpdateResponse(
            new StatusUpdateData(),
            new Status(true, "OK", "200")
        );

        when(mockClient.updateTransactionStatus(any(StatusUpdateRequest.class))).thenReturn(expectedResponse);

        // When
        StatusUpdateResponse response = api.updateTransactionStatus(requestUUID, requestId,
                transactionId, statusCode, status, description);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).updateTransactionStatus(any(StatusUpdateRequest.class));
    }

    @Test
    public void testGetDynamicQRTransactionStatus() throws Exception {
        // Given
        String requestUUID = "uuid123";

        DynamicQRStatusData data =new DynamicQRStatusData(null, "SUCCESS", true, "ACSP");
        DynamicQRStatusResponse expectedResponse = new DynamicQRStatusResponse();
        expectedResponse.setData(data);

        when(mockClient.getDynamicQRTransactionStatus(any(DynamicQRStatusRequest.class))).thenReturn(expectedResponse);

        // When
        DynamicQRStatusResponse response = api.getDynamicQRTransactionStatus(requestUUID);

        // Then
        assertEquals(expectedResponse, response);
        verify(mockClient).getDynamicQRTransactionStatus(any(DynamicQRStatusRequest.class));
    }
}
