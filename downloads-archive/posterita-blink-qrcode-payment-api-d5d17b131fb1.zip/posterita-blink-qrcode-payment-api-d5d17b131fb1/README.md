# Blink Payment API Java Library

A Java library for integrating with Emtel's Blink Payment System API.

## Features

- Authentication (Token API)
- Debit/Initiate Transaction
- Transaction Status Inquiry
- Dynamic QR Code Generation
- Status Update
- Dynamic QR Transaction Status
- AES Encryption/Decryption for secure communication

## Installation

Add the following dependency to your `pom.xml`:

```xml
<dependency>
    <groupId>com.emtel</groupId>
    <artifactId>blink-payment-api</artifactId>
    <version>1.0.0</version>
</dependency>
```

## Usage

### Basic Usage

```java
import com.emtel.blink.dynamicqrcode.BlinkPaymentApi;
import com.emtel.blink.dynamicqrcode.model.*;

// Create API instance (false for UAT, true for Production)
BlinkPaymentApi api = new BlinkPaymentApi(false);

// Authenticate
String requestId = "TEST1234350001";
TokenResponse tokenResponse = api.authenticate(requestId);

// Initiate a transaction
DebitResponse debitResponse = api.initiateTransaction(
    "00020101021126610009mu.maucas0112EMFSMUM0XXXX020910002300303150000000000000165202AA53034805802MU59...",
    "533233323",
    "58580000",
    new BigDecimal("100.00"),
    "123456887654",
    "TEST1234350001"
);

// Check transaction status
TransactionStatusResponse statusResponse = api.getTransactionStatus("123456887654", "ECOMTXN2022071112051159");

// Generate QR Code
QRCodeResponse qrResponse = api.getQRCode(
    "252431455610708101",
    "id_order_987245_test11",
    "00020101021126610009mu.maucas0112EMFSMUM0XXXX02091000850040315000000000000045202AA53034805802MU5...",
    "Test Transaction",
    new BigDecimal("234.60"),
    new BigDecimal("0"),
    false
);
```

### Configuration

The library automatically handles:
- Environment selection (UAT/Production)
- Encryption keys
- API endpoints
- Authentication tokens and sessions

### Error Handling

All methods throw `Exception` for encryption/network errors. Check the `Status` object in responses for API-level errors.

```java
try {
    TokenResponse response = api.authenticate("requestId");
    if (response.getStatus().isSuccess()) {
        // Success
    } else {
        // Handle error: response.getStatus().getMessage()
    }
} catch (Exception e) {
    // Handle exception
}
```

## API Methods

- `authenticate(String requestIndentityId)`: Get authentication token
- `initiateTransaction(...)`: Start a payment transaction
- `getTransactionStatus(String requestUUID, String ecomRequestId)`: Check transaction status
- `getQRCode(...)`: Generate dynamic QR code
- `updateTransactionStatus(...)`: Update transaction status
- `getDynamicQRTransactionStatus(String requestUUID)`: Get dynamic QR transaction status

## Security

The library uses AES-256-CBC encryption with PKCS5 padding for secure communication with the Blink API.

## Dependencies

- Jackson: JSON processing

## Testing

### Unit Tests
Run unit tests (with mocks):
```bash
mvn test
```

The project uses **JUnit 5** for testing with the following features:
- Modern assertions with `org.junit.jupiter.api.Assertions`
- `@BeforeEach` instead of `@Before`
- `@Disabled` instead of `@Ignore` for skipping tests
- Lambda expressions for exception testing with `assertThrows()`

### Integration Tests
The library includes integration tests that make real API calls to the Blink Payment System.

**⚠️ WARNING: Integration tests make real API calls and may incur costs or affect real data.**

To run integration tests safely:

1. **Use UAT Environment**: Integration tests are configured for UAT (testing) environment
2. **Remove @Disabled**: Edit `BlinkPaymentApiIntegrationTest.java` and remove `@Disabled` annotations
3. **Run Specific Tests**: Only run non-financial tests first (authentication, QR generation)
4. **Avoid Real Transactions**: The transaction initiation test is double-ignored for safety

```bash
# Run all tests including integration (after removing @Disabled)
mvn test

# Run only integration tests
mvn test -Dtest=BlinkPaymentApiIntegrationTest

# Run specific integration test method
mvn test -Dtest=BlinkPaymentApiIntegrationTest#testRealAuthentication
```

### Available Integration Tests
- **Authentication Test**: Tests token generation
- **QR Code Generation**: Tests dynamic QR code creation
- **Transaction Status**: Tests status checking (safe)
- **Dynamic QR Status**: Tests QR transaction status
- **Transaction Initiation**: ⚠️ **DISABLED BY DEFAULT** - Makes real transactions

### Test Configuration
Integration tests use the UAT environment with test credentials from `BlinkConfig`:
- Base URL: `https://fin-staging.emtel.com`
- Test keys and credentials are pre-configured

## License

This library is provided as-is for integration with Emtel's Blink Payment System.
