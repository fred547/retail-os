/* eslint-disable camelcase */
const axios = require('axios');
const crypto = require('crypto');


const ENV_URLS = {
  UAT: {
    TOKEN_URL: 'https://fin-staging.emtel.com/EcomAPI/GetAuthToken',
    DEBIT_URL: 'https://fin-staging.emtel.com/EcomAPI/InitiateTransactionRequest',
    STATUS_URL: 'https://fin-staging.emtel.com/EcomAPI/GetTransactionStatus',
    QR_URL: 'https://fin-staging.emtel.com/EcomAPI/GetQRCode',
    DYN_QR_STATUS_URL: 'https://fin-staging.emtel.com/EcomAPI/GetDynamicQRTransactionStatus'
  },
  PROD: {
    TOKEN_URL: 'https://blink-app.emtel.com/EcomAPI-V1/GetAuthToken',
    DEBIT_URL: 'https://blink-app.emtel.com/EcomAPI-V1/InitiateTransactionRequest',
    STATUS_URL: 'https://blink-app.emtel.com/EcomAPI-V1/GetTransactionStatus',
    QR_URL: 'https://blink-app.emtel.com/EcomAPI-V1/GetQRCode',
    DYN_QR_STATUS_URL: 'https://blink-app.emtel.com/EcomAPI-V1/GetDynamicQRTransactionStatus'
  }
};


class BlinkClient {
  constructor(mode = 'UAT') {
    const urls = ENV_URLS[mode] || ENV_URLS.UAT;
    if (mode === 'PROD') {
      this.cfg = {
        ...urls,
        AES_KEY: process.env.BLINK_PROD_AES_KEY,
        AES_IV: process.env.BLINK_PROD_AES_IV,
        USER: process.env.BLINK_PROD_USER,
        PASS: process.env.BLINK_PROD_PASS
      };
    } else {
      this.cfg = {
        ...urls,
        AES_KEY: process.env.BLINK_UAT_AES_KEY,
        AES_IV: process.env.BLINK_UAT_AES_IV,
        USER: process.env.BLINK_UAT_USER,
        PASS: process.env.BLINK_UAT_PASS
      };
    }
  }

  /* ---------- helpers ---------- */
  _aesEncrypt(plainObj) {
    const { AES_KEY, AES_IV } = this.cfg;
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(AES_KEY, 'utf8'), Buffer.from(AES_IV, 'utf8'));
    let encrypted = cipher.update(JSON.stringify(plainObj), 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return { body: encrypted };
  }

  _aesDecrypt(base64) {
    const { AES_KEY, AES_IV } = this.cfg;
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(AES_KEY, 'utf8'), Buffer.from(AES_IV, 'utf8'));
    let dec = decipher.update(base64, 'base64', 'utf8');
    dec += decipher.final('utf8');
    return JSON.parse(dec);
  }

  async _post(url, payload, headers = {}) {
    const res = await axios.post(url, payload, { headers });
    return res.data;
  }

  /* ---------- token ---------- */
  async getToken(requestIndentityId) {
    const payload = {
      requestIndentityId,
      userName: this.cfg.USER,
      password: this.cfg.PASS
    };

    const encryptedPayload = this._aesEncrypt(payload);

    let response = await this._post(this.cfg.TOKEN_URL, encryptedPayload);

    if(response.data){
        try {
            response.data = JSON.parse(this._aesDecrypt(response.data));
        } catch (error) {
            
        }
    }

    return response;
  }

  /* ---------- debit ---------- */
  async initiateDebit(bodyPlain, { token, sessionId }) {
    const encrypted = this._aesEncrypt(bodyPlain);
    const headers = {
      'Content-Type': 'application/json',
      Authorization: token,
      SessionId: sessionId
    };
    const res = await this._post(this.cfg.DEBIT_URL, encrypted, headers);
    if (res.data) res.data = this._aesDecrypt(res.data);
    return res;
  }

  /* ---------- txn status ---------- */
  async getTransactionStatus(bodyPlain, { token, sessionId }) {
    const encrypted = this._aesEncrypt(bodyPlain);
    const headers = {
      'Content-Type': 'application/json',
      Authorization: token,
      SessionId: sessionId
    };
    const res = await this._post(this.cfg.STATUS_URL, encrypted, headers);
    if (res.data) res.data = this._aesDecrypt(res.data);
    return res;
  }

  /* ---------- dynamic QR ---------- */
  async getDynamicQR(bodyPlain, { token, sessionId }) {
    const encrypted = this._aesEncrypt(bodyPlain);
    const headers = {
      'Content-Type': 'application/json',
      Authorization: token,
      SessionId: sessionId
    };
    const res = await this._post(this.cfg.QR_URL, encrypted, headers);
    if (res.data) res.data = this._aesDecrypt(res.data);
    return res;
  }

  /* ---------- dynamic QR status ---------- */
  async getDynamicQRStatus(bodyPlain, { token, sessionId }) {
    const encrypted = this._aesEncrypt(bodyPlain);
    const headers = {
      'Content-Type': 'application/json',
      Authorization: token,
      SessionId: sessionId
    };
    const res = await this._post(this.cfg.DYN_QR_STATUS_URL, encrypted, headers);
    if (res.data) res.data = this._aesDecrypt(res.data);
    return res;
  }

  /* ---------- status update (webhook mock) ---------- */
  async sendStatusUpdate(url, body) {
    return this._post(url, body);
  }
}

module.exports = { BlinkClient };