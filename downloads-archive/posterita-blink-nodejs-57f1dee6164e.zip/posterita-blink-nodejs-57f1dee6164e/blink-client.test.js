/**
 * @jest-environment node
 */

const { BlinkClient } = require('./blink-client.js');
const dotenv = require('dotenv');
dotenv.config();
const axios = require('axios');

jest.mock('axios');

const client = new BlinkClient('UAT');

describe('Blink API – UAT smoke tests', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('1. getToken – success', async () => {
    const mockResponse = {
      status: { i: true },
      data: { token: 'mockToken', sessionId: 'mockSessionId' }
    };
    axios.post.mockResolvedValueOnce({ data: mockResponse });
    const spy = jest.spyOn(axios, 'post');
    const res = await client.getToken('TEST1234300011013');
    expect(spy).toHaveBeenCalled();
    expect(res.status.i).toBe(true);
    expect(res.data.token).toBe('mockToken');
    expect(res.data.sessionId).toBe('mockSessionId');
  });

  test('2. initiateDebit – success', async () => {
    const token = 'mockToken';
    const sessionId = 'mockSessionId';
    const body = {
      merchantQRCode:
        '00020101021126610009mu.maucas0112EMFSMUM0XXXX020910005007703150000000000000685204569953034805802MU5905ddsds6010Port Louis621902085343433407031436304F78D',
      merchantStoreMobileNo: '53434334',
      customerMobileNo: '52543112',
      amount: 111.0,
      requestUUID: 'REQ12345688110241011',
      requestIndentityId: 'TEST1234300011013'
    };
    const mockResponse = {
      status: { i: true },
      data: { ecomRequestId: 'ECOMTXN2022010112345678' }
    };
    axios.post.mockResolvedValueOnce({ data: { data: 'encrypted-string', status: { i: true } } });
    const spy = jest.spyOn(axios, 'post');
    const decryptSpy = jest.spyOn(client, '_aesDecrypt').mockReturnValueOnce(mockResponse.data);
    const res = await client.initiateDebit(body, { token, sessionId });
    expect(spy).toHaveBeenCalled();
    expect(decryptSpy).toHaveBeenCalled();
    expect(res.status.i).toBe(true);
    expect(res.data.ecomRequestId).toMatch(/ECOMTXN\d{8}\d{8}/);
  });

  test('3. getTransactionStatus – success', async () => {
    const token = 'mockToken';
    const sessionId = 'mockSessionId';
    const body = {
      requestUUID: 'REQ12345688110241011',
      ecomRequestId: 'ECOMTXN2022092070457094'
    };
    const mockResponse = {
      status: { i: true },
      data: { transactionId: 'EMFSMUM123456' }
    };
    axios.post.mockResolvedValueOnce({ data: { data: 'encrypted-string', status: { i: true } } });
    const spy = jest.spyOn(axios, 'post');
    const decryptSpy = jest.spyOn(client, '_aesDecrypt').mockReturnValueOnce(mockResponse.data);
    const res = await client.getTransactionStatus(body, { token, sessionId });
    expect(spy).toHaveBeenCalled();
    expect(decryptSpy).toHaveBeenCalled();
    expect(res.status.i).toBe(true);
    expect(res.data.transactionId).toMatch(/EMFSMUM/);
  });

  test('4. getDynamicQR – success', async () => {
    const token = 'mockToken';
    const sessionId = 'mockSessionId';
    const body = {
      requestUUID: '252431455610708101',
      requestIndentityId: 'id_order_987245_test11',
      qrCodeString:
        '00020101021126610009mu.maucas0112EMFSMUM0XXXX02091000850040315000000000000045202AA53034805802MU5904test6010Port Louis6222020854131232070614016563046A33',
      purposeOfTransaction: 'string1324567_test',
      transactionAmount: 234.6,
      convenienceCharges: 0,
      isPercentageConvenienceCharges: false
    };
    const mockResponse = {
      status: { i: true },
      data: { qrCodeString: '00020101021126610009mu.maucas0112EMFSMUM0XXXX' }
    };
    axios.post.mockResolvedValueOnce({ data: { data: 'encrypted-string', status: { i: true } } });
    const spy = jest.spyOn(axios, 'post');
    const decryptSpy = jest.spyOn(client, '_aesDecrypt').mockReturnValueOnce(mockResponse.data);
    const res = await client.getDynamicQR(body, { token, sessionId });
    expect(spy).toHaveBeenCalled();
    expect(decryptSpy).toHaveBeenCalled();
    expect(res.status.i).toBe(true);
    expect(res.data.qrCodeString).toContain('mu.maucas');
  });

  test('5. getDynamicQRStatus – success', async () => {
    const token = 'mockToken';
    const sessionId = 'mockSessionId';
    const body = { requestUUID: '12345676789976' };
    const mockResponse = {
      transactionResponse: 'SUCCESS'
    };
    axios.post.mockResolvedValueOnce({ data: { data: 'encrypted-string' } });
    const spy = jest.spyOn(axios, 'post');
    const decryptSpy = jest.spyOn(client, '_aesDecrypt').mockReturnValueOnce(mockResponse);
    const res = await client.getDynamicQRStatus(body, { token, sessionId });
    const status = res.transactionResponse || (res.data && res.data.transactionResponse);
    expect(spy).toHaveBeenCalled();
    expect(decryptSpy).toHaveBeenCalled();
    expect(['SUCCESS', 'FAILED', 'PENDING']).toContain(status);
  });

  test('6. getToken – wrong password => ACCERR', async () => {
    const badClient = new BlinkClient('UAT');
    badClient.cfg.PASS = 'wrong';
    const mockResponse = {
      status: { i: false, s: 'ACCERR' }
    };
    axios.post.mockResolvedValueOnce({ data: mockResponse });
    const spy = jest.spyOn(axios, 'post');
    const res = await badClient.getToken('TEST1234300011013');
    expect(spy).toHaveBeenCalled();
    expect(res.status.i).toBe(false);
    expect(res.status.s).toBe('ACCERR');
  });
});